# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## random-insertions

1500 logical operations per replay.

### singapore

CPU: 511 in-workload samples; 40 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 283 | 55.4% |
| reverse index | 100 | 19.6% |
| adapter / harness / other | 50 | 9.8% |
| edit preparation / boundary policy | 39 | 7.6% |
| buffer store / line index | 39 | 7.6% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:118:insertIntoPieceTable`: 98.4% of in-workload samples.
- `textbuffer/dist/edits.js:127:insertTextAt`: 83.4% of in-workload samples.
- `textbuffer/dist/tree.js:73:splitByVisibleOffset`: 32.1% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:65:applyReverseIndexChanges`: 19.6% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:43:insertReverseIndexNode`: 18.8% of in-workload samples.
- `textbuffer/dist/tree.js:59:merge`: 18.4% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":27,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 375 | 0.25 |
| buffers.growTailLineIndex.indexInputCodeUnits | 2249 | 1.50 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| edits.snapEditRange.calls | 1500 | 1.00 |
| edits.tryCoalesceInsert.calls | 1500 | 1.00 |
| priority.priorityForPiece.calls | 7485 | 4.99 |
| reads.splitsSurrogatePair.calls | 3000 | 2.00 |
| reverseIndex.cloneReverseIndexNode.calls | 29576 | 19.72 |
| reverseIndex.createReverseIndexNode.calls | 2995 | 2.00 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1495 | 1.00 |
| reverseIndex.ownReverseIndexNode.calls | 57336 | 38.22 |
| tree.cloneNode.calls | 17988 | 11.99 |
| tree.createNode.calls | 4490 | 2.99 |
| tree.own.calls | 47401 | 31.60 |

### vscode

CPU: 159 in-workload samples; 34 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 102 | 64.2% |
| red-black tree | 50 | 31.4% |
| adapter / harness / other | 7 | 4.4% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 95.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 27.7% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 27.0% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 26.4% of in-workload samples.
- `vscode/dist/rbTreeBase.js:355:recomputeTreeMetadata`: 17.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 16.4% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 2250 | 1.50 |
| pieceTreeBase.createLineStartsFast.loopIterations | 2250 | 1.50 |
| rbTreeBase.leftRotate.calls | 1800 | 1.20 |
| rbTreeBase.rightRotate.calls | 1800 | 1.20 |
| rbTreeBase.TreeNode.constructor.calls | 2995 | 2.00 |

## random-replacements

1500 logical operations per replay.

### vscode

CPU: 191 in-workload samples; 32 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 128 | 67.0% |
| red-black tree | 59 | 30.9% |
| adapter / harness / other | 4 | 2.1% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 52.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 45.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 33.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:936:shrinkNode`: 22.0% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 20.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 20.9% of in-workload samples.

Structure after workload: {"pieces":2917,"invisible":0,"visible":2917,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 3380 | 2.25 |
| pieceTreeBase.createLineStartsFast.loopIterations | 3380 | 2.25 |
| rbTreeBase.leftRotate.calls | 1726 | 1.15 |
| rbTreeBase.rightRotate.calls | 1755 | 1.17 |
| rbTreeBase.TreeNode.constructor.calls | 2950 | 1.97 |

### singapore

CPU: 1027 in-workload samples; 55 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 622 | 60.6% |
| reverse index | 182 | 17.7% |
| buffer store / line index | 84 | 8.2% |
| adapter / harness / other | 75 | 7.3% |
| edit preparation / boundary policy | 64 | 6.2% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:169:deleteFromPieceTable`: 61.2% of in-workload samples.
- `textbuffer/dist/edits.js:175:deleteRange`: 54.8% of in-workload samples.
- `textbuffer/dist/tree.js:73:splitByVisibleOffset`: 40.3% of in-workload samples.
- `textbuffer/dist/edits.js:118:insertIntoPieceTable`: 37.5% of in-workload samples.
- `textbuffer/dist/edits.js:127:insertTextAt`: 33.1% of in-workload samples.
- `textbuffer/dist/tree.js:48:updateNode`: 22.7% of in-workload samples.

Structure after workload: {"pieces":4437,"invisible":1520,"visible":2917,"maxDepth":32,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 187 | 0.12 |
| buffers.extendBufferLineIndex.indexInputCodeUnits | 1860 | 1.24 |
| buffers.extendBufferLineIndex.loopIterations | 103 | 0.07 |
| buffers.growTailLineIndex.indexInputCodeUnits | 3376 | 2.25 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| buffers.pushLineBreakOffset.typedArrayCapacityBytes | 1792 | 1.19 |
| buffers.pushLineBreakOffset.typedArrayCopiedBytes | 768 | 0.51 |
| edits.snapEditRange.calls | 2953 | 1.97 |
| edits.tryCoalesceInsert.calls | 1500 | 1.00 |
| priority.priorityForPiece.calls | 11808 | 7.87 |
| reads.splitsSurrogatePair.calls | 5906 | 3.94 |
| reverseIndex.cloneReverseIndexNode.calls | 36567 | 24.38 |
| reverseIndex.createReverseIndexNode.calls | 4436 | 2.96 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 4491 | 2.99 |
| reverseIndex.ownReverseIndexNode.calls | 125888 | 83.93 |
| tree.cloneNode.calls | 40380 | 26.92 |
| tree.createNode.calls | 7372 | 4.91 |
| tree.own.calls | 112848 | 75.23 |

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

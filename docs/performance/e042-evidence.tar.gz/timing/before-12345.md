# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 26e805c28e993ebec1947ed88df823b429e6b969.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.537 / 0.541 | 0.620 / 0.654 | 0.87x |
| typing-with-lookups | 3000 | 0.744 / 0.751 | 0.971 / 1.062 | 0.77x |
| random-insertions | 1500 | 4.953 / 5.174 | 1.080 / 1.185 | 4.59x |
| random-replacements | 1500 | 8.827 / 9.061 | 1.358 / 1.426 | 6.50x |
| eight-cursor-batches | 187 | 5.330 / 5.441 | 1.201 / 1.241 | 4.44x |
| mixed-edit-churn | 1500 | 8.240 / 11.090 | 1.237 / 1.351 | 6.66x |
| persistent-history | 1500 | 7.867 / 8.167 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 64744 | 65536 | 65536 |
| sequential-typing | vscode | 89312 | 40004 | 40004 |
| typing-with-lookups | singapore | 42072 | 66560 | 66560 |
| typing-with-lookups | vscode | 89664 | 40004 | 40004 |
| random-insertions | singapore | -428072 | 65536 | 65536 |
| random-insertions | vscode | 619120 | 40004 | 40004 |
| random-replacements | singapore | -820064 | 66560 | 66560 |
| random-replacements | vscode | 648888 | 40004 | 40004 |
| eight-cursor-batches | singapore | -433936 | 66560 | 66560 |
| eight-cursor-batches | vscode | 576920 | 40004 | 40004 |
| mixed-edit-churn | singapore | -351024 | 66560 | 66560 |
| mixed-edit-churn | vscode | 540752 | 40004 | 40004 |
| persistent-history | singapore | 4126400 | 66560 | 66560 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

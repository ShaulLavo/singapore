# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 26e805c28e993ebec1947ed88df823b429e6b969.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.646 / 0.656 | 0.600 / 0.626 | 1.08x |
| typing-with-lookups | 3000 | 0.897 / 1.281 | 0.935 / 1.022 | 0.96x |
| random-insertions | 1500 | 4.004 / 4.091 | 1.079 / 1.116 | 3.71x |
| random-replacements | 1500 | 6.905 / 7.118 | 1.382 / 1.413 | 4.99x |
| eight-cursor-batches | 187 | 3.970 / 4.007 | 1.168 / 1.237 | 3.40x |
| mixed-edit-churn | 1500 | 6.197 / 6.294 | 1.142 / 1.303 | 5.43x |
| persistent-history | 1500 | 6.195 / 6.236 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 64728 | 65536 | 65536 |
| sequential-typing | vscode | 89176 | 40004 | 40004 |
| typing-with-lookups | singapore | 57504 | 66560 | 66560 |
| typing-with-lookups | vscode | 89264 | 40004 | 40004 |
| random-insertions | singapore | -432936 | 65536 | 65536 |
| random-insertions | vscode | 617032 | 40004 | 40004 |
| random-replacements | singapore | -831392 | 66560 | 66560 |
| random-replacements | vscode | 647864 | 40004 | 40004 |
| eight-cursor-batches | singapore | -442472 | 66560 | 66560 |
| eight-cursor-batches | vscode | 587944 | 40004 | 40004 |
| mixed-edit-churn | singapore | -345672 | 66048 | 66048 |
| mixed-edit-churn | vscode | 543576 | 40004 | 40004 |
| persistent-history | singapore | 4138088 | 66048 | 66048 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

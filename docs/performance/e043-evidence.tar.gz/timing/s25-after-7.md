# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: b7fea3c4e2330a2dbef3174ecfa965572eb5cc36.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.699 / 0.719 | 0.605 / 0.638 | 1.16x |
| typing-with-lookups | 3000 | 0.955 / 0.989 | 0.933 / 0.987 | 1.02x |
| random-insertions | 1500 | 3.536 / 3.687 | 1.087 / 1.204 | 3.25x |
| random-replacements | 1500 | 7.260 / 9.158 | 1.377 / 1.455 | 5.27x |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 63248 | 65536 | 65536 |
| sequential-typing | vscode | 89176 | 40004 | 40004 |
| typing-with-lookups | singapore | 64232 | 66560 | 66560 |
| typing-with-lookups | vscode | 89520 | 40004 | 40004 |
| random-insertions | singapore | -432528 | 65536 | 65536 |
| random-insertions | vscode | 609864 | 40004 | 40004 |
| random-replacements | singapore | -830928 | 66560 | 66560 |
| random-replacements | vscode | 644896 | 40004 | 40004 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

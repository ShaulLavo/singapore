# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: b7fea3c4e2330a2dbef3174ecfa965572eb5cc36.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.515 / 0.522 | 0.602 / 0.645 | 0.86x |
| typing-with-lookups | 3000 | 0.731 / 0.764 | 0.938 / 1.023 | 0.78x |
| random-insertions | 1500 | 3.900 / 3.968 | 1.072 / 1.843 | 3.64x |
| random-replacements | 1500 | 6.942 / 7.192 | 1.378 / 1.432 | 5.04x |
| eight-cursor-batches | 187 | 4.290 / 4.400 | 1.228 / 1.395 | 3.49x |
| mixed-edit-churn | 1500 | 6.378 / 6.610 | 1.264 / 1.360 | 5.05x |
| persistent-history | 1500 | 6.346 / 6.402 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 64608 | 65536 | 65536 |
| sequential-typing | vscode | 89224 | 40004 | 40004 |
| typing-with-lookups | singapore | 42320 | 66560 | 66560 |
| typing-with-lookups | vscode | 78248 | 40004 | 40004 |
| random-insertions | singapore | -434184 | 65536 | 65536 |
| random-insertions | vscode | 618784 | 40004 | 40004 |
| random-replacements | singapore | -829616 | 66560 | 66560 |
| random-replacements | vscode | 649320 | 40004 | 40004 |
| eight-cursor-batches | singapore | -433848 | 66560 | 66560 |
| eight-cursor-batches | vscode | 574984 | 40004 | 40004 |
| mixed-edit-churn | singapore | -335640 | 66560 | 66560 |
| mixed-edit-churn | vscode | 541472 | 40004 | 40004 |
| persistent-history | singapore | 4120184 | 66560 | 66560 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

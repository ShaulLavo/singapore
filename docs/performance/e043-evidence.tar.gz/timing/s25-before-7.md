# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: b7fea3c4e2330a2dbef3174ecfa965572eb5cc36.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.642 / 0.654 | 0.603 / 0.646 | 1.06x |
| typing-with-lookups | 3000 | 0.895 / 0.917 | 0.957 / 1.019 | 0.94x |
| random-insertions | 1500 | 3.961 / 4.132 | 1.071 / 1.174 | 3.70x |
| random-replacements | 1500 | 6.916 / 7.341 | 1.372 / 1.428 | 5.04x |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 64648 | 65536 | 65536 |
| sequential-typing | vscode | 89176 | 40004 | 40004 |
| typing-with-lookups | singapore | 50728 | 66560 | 66560 |
| typing-with-lookups | vscode | 89592 | 40004 | 40004 |
| random-insertions | singapore | -432808 | 65536 | 65536 |
| random-insertions | vscode | 617032 | 40004 | 40004 |
| random-replacements | singapore | -831768 | 66560 | 66560 |
| random-replacements | vscode | 644000 | 40004 | 40004 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

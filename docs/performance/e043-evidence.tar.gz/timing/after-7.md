# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: b7fea3c4e2330a2dbef3174ecfa965572eb5cc36.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.704 / 0.715 | 0.607 / 0.621 | 1.16x |
| typing-with-lookups | 3000 | 0.956 / 0.970 | 0.916 / 1.022 | 1.04x |
| random-insertions | 1500 | 3.547 / 3.700 | 1.072 / 1.160 | 3.31x |
| random-replacements | 1500 | 7.189 / 7.620 | 1.370 / 1.452 | 5.25x |
| eight-cursor-batches | 187 | 3.770 / 3.891 | 1.151 / 1.222 | 3.27x |
| mixed-edit-churn | 1500 | 6.125 / 6.241 | 1.198 / 1.387 | 5.11x |
| persistent-history | 1500 | 6.160 / 6.286 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 63152 | 65536 | 65536 |
| sequential-typing | vscode | 89176 | 40004 | 40004 |
| typing-with-lookups | singapore | 48928 | 66560 | 66560 |
| typing-with-lookups | vscode | 89592 | 40004 | 40004 |
| random-insertions | singapore | -432400 | 65536 | 65536 |
| random-insertions | vscode | 617032 | 40004 | 40004 |
| random-replacements | singapore | -830616 | 66560 | 66560 |
| random-replacements | vscode | 647864 | 40004 | 40004 |
| eight-cursor-batches | singapore | -442336 | 66560 | 66560 |
| eight-cursor-batches | vscode | 587776 | 40004 | 40004 |
| mixed-edit-churn | singapore | -346048 | 66048 | 66048 |
| mixed-edit-churn | vscode | 536360 | 40004 | 40004 |
| persistent-history | singapore | 4139800 | 66048 | 66048 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

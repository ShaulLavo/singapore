# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## random-insertions

1500 logical operations per replay.

### singapore

CPU: 441 in-workload samples; 42 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 239 | 54.2% |
| reverse index | 106 | 24.0% |
| buffer store / line index | 54 | 12.2% |
| edit preparation / boundary policy | 31 | 7.0% |
| adapter / harness / other | 11 | 2.5% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:118:insertIntoPieceTable`: 97.5% of in-workload samples.
- `textbuffer/dist/edits.js:131:insertTextAt`: 96.6% of in-workload samples.
- `textbuffer/dist/edits.js:162:finishInsert`: 55.3% of in-workload samples.
- `textbuffer/dist/tree.js:183:splitByVisibleOffset`: 40.1% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:65:applyReverseIndexChanges`: 24.0% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:43:insertReverseIndexNode`: 22.9% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":27,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 375 | 0.25 |
| buffers.growTailLineIndex.indexInputCodeUnits | 2249 | 1.50 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| priority.priorityForPiece.calls | 7485 | 4.99 |
| reverseIndex.cloneReverseIndexNode.calls | 29576 | 19.72 |
| reverseIndex.createReverseIndexNode.calls | 2995 | 2.00 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1495 | 1.00 |
| reverseIndex.ownReverseIndexNode.calls | 57336 | 38.22 |
| tree.cloneNode.calls | 17988 | 11.99 |
| tree.createNode.calls | 4490 | 2.99 |
| tree.own.calls | 47401 | 31.60 |

### vscode

CPU: 154 in-workload samples; 28 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 98 | 63.6% |
| red-black tree | 53 | 34.4% |
| adapter / harness / other | 3 | 1.9% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 98.1% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 28.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 28.6% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 27.3% of in-workload samples.
- `vscode/dist/rbTreeBase.js:355:recomputeTreeMetadata`: 15.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 12.3% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 2250 | 1.50 |
| pieceTreeBase.createLineStartsFast.loopIterations | 2250 | 1.50 |
| rbTreeBase.leftRotate.calls | 1800 | 1.20 |
| rbTreeBase.rightRotate.calls | 1800 | 1.20 |
| rbTreeBase.TreeNode.constructor.calls | 2995 | 2.00 |

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

# E046 evidence

- `drive.mjs`, `lane.mjs`, `fixtures.mjs`: the throwaway driver. One fresh Node process per sample, builds
  interleaved, median per seed, then median over seeds 20260916, 7 and 12345. The measured run shares the
  warmups' call site and validates between warmups, as the bench's worker does. A build is
  `name=engine:benchDir:distRoot`; the baseline runs with a frozen copy of the baseline bench adapters.
- `s2-8w.jsonl`, `s3-8w.jsonl`, `s3b-8w.jsonl`, `s5-8w.jsonl`: each step against the baseline. `s3b` is a module
  scratch object for the row bounds against one allocated per call: no difference, so the allocation stayed.
- `final-all-2w.jsonl`, `final-all-8w.jsonl`: every lane, baseline against the final build, 9 samples, with
  retained heap in KB.
- `profile-base/`, `profile-final/`: `bench:profile` cpu and counters at 40 replays. `selfshare.mjs` prints the
  self-time shares the report quotes.
- `official/`: `bun run bench` summaries of the final build, three seeds, 2 and 8 warmups. `readme-table.mjs`
  builds the README table from their JSON.
- `maps.mjs`: hidden classes of the live pieces after the anchor-density trace; run with `--allow-natives-syntax`.
- `regex.mjs`: the cost of the surrogate test at load.
- `editor-bench.mjs`, `editor-bench-before.json`, `editor-bench-after.json`: medians of 9 runs of the editor's
  virtualization and walker benches.
- `budgets-before.json`: the counter budgets of the baseline.
- `anchor-density-modes.txt`: the lane's two modes across seeds and warmup counts, and the checks that rule out piece size.

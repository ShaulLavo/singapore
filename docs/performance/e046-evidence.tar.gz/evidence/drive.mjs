// node drive.mjs <warmups> <samples> <name=engine:benchDir:distRoot>... ; interleaved, median per seed, then over seeds
import { execFileSync } from 'node:child_process'
const [warmups, samples, ...builds] = process.argv.slice(2)
const lanes = (process.env.LANES ?? 'position-to-offset,lines-sequential-after-churn,lines-random-after-churn,random-replacements,mixed-edit-churn').split(',')
const seeds = (process.env.SEEDS ?? '20260916,7,12345').split(',')
const median = (values) => values.toSorted((a, b) => a - b)[values.length >> 1]
const parsed = builds.map((build) => { const [name, spec] = build.split('='); const [engine, bench, root] = spec.split(':'); return { name, engine, bench, root } })
for (const lane of lanes) {
  const row = { lane, warmups: Number(warmups) }
  const perSeed = Object.fromEntries(parsed.map((b) => [b.name, { ms: [], heap: [] }]))
  for (const seed of seeds) {
    const runs = Object.fromEntries(parsed.map((b) => [b.name, { ms: [], heap: [] }]))
    for (let sample = 0; sample < Number(samples); sample += 1)
      for (const b of sample % 2 ? parsed.toReversed() : parsed) {
        const out = JSON.parse(execFileSync('node', ['--expose-gc', new URL('lane.mjs', import.meta.url).pathname, b.engine, b.bench, b.root ?? '-', lane, warmups, seed], { encoding: 'utf8' }))
        runs[b.name].ms.push(out.ms); runs[b.name].heap.push(out.heap + out.external)
      }
    for (const b of parsed) { perSeed[b.name].ms.push(median(runs[b.name].ms)); perSeed[b.name].heap.push(median(runs[b.name].heap)) }
  }
  for (const b of parsed) { row[b.name] = Number(median(perSeed[b.name].ms).toFixed(3)); row[`${b.name}.kb`] = Math.round(median(perSeed[b.name].heap) / 1024) }
  console.log(JSON.stringify(row))
}

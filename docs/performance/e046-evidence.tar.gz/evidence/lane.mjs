// One fresh-process sample: node --expose-gc lane.mjs <engine> <benchDir> <distRoot|-> <lane> <warmups> <seed>
import path from 'node:path'
import { readFileSync } from 'node:fs'
const [engine, bench, root, lane, warmups, seed] = process.argv.slice(2)
const { loadAdapter } = await import(path.join(bench, 'adapters.mjs'))
const { execute, validate } = await import(path.join(bench, 'worker.mjs'))
const fixture = JSON.parse(readFileSync(new URL(`fixtures/${seed}-${lane}.json`, import.meta.url), 'utf8'))
const factory = await loadAdapter(engine, engine === 'singapore' ? { singapore: root } : {})
// One call site for warmups and the measured run, validated between, as the bench's worker does.
let result
for (let index = 0; index <= Number(warmups); index += 1) {
  result = execute(factory, fixture)
  validate(factory, fixture, result)
}
process.stdout.write(JSON.stringify({ ms: result.elapsedMs, heap: result.retainedBytes.heapUsed, external: result.retainedBytes.external }) + '\n')

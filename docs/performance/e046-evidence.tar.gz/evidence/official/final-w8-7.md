# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 2994378da48e31a0a047c155886dfdb49081ecfd.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| load-short-lines | 1 | 1.614 / 1.693 | 2.062 / 2.069 | 0.78x |
| load-long-line | 1 | 1.076 / 1.101 | 1.285 / 1.313 | 0.84x |
| sequential-typing | 1500 | 0.377 / 0.393 | 0.379 / 0.423 | 0.99x |
| typing-with-lookups | 3000 | 0.571 / 0.579 | 0.776 / 0.848 | 0.74x |
| random-insertions | 1500 | 1.219 / 1.308 | 0.965 / 0.986 | 1.26x |
| random-replacements | 1500 | 1.877 / 2.020 | 1.241 / 1.296 | 1.51x |
| eight-cursor-batches | 187 | 1.565 / 1.646 | 1.041 / 1.105 | 1.50x |
| mixed-edit-churn | 1500 | 1.928 / 2.003 | 1.056 / 1.092 | 1.83x |
| large-paste-delete | 32 | 4.533 / 4.609 | 12.255 / 12.790 | 0.37x |
| lines-sequential-after-churn | 3000 | 0.545 / 0.555 | 0.328 / 0.393 | 1.66x |
| lines-random-after-churn | 3000 | 0.774 / 0.790 | 0.618 / 0.690 | 1.25x |
| ranges-after-churn | 3000 | 1.146 / 1.184 | 2.733 / 2.767 | 0.42x |
| offset-to-position | 3000 | 0.603 / 0.624 | 0.682 / 1.023 | 0.89x |
| position-to-offset | 3000 | 0.468 / 0.471 | 0.293 / 0.309 | 1.60x |
| full-read-after-churn | 12 | 1.712 / 1.780 | 1.193 / 1.362 | 1.44x |
| persistent-history | 1500 | 2.086 / 2.156 | not equivalent | separate lane |
| branch-edits | 64 | 0.213 / 0.229 | not equivalent | separate lane |
| anchor-resolution-after-churn | 3000 | 0.313 / 0.322 | not equivalent | separate lane |
| anchor-density | 300 | 11.128 / 11.381 | not equivalent | separate lane |
| ascii-replacements | 1500 | 1.849 / 1.919 | 1.225 / 1.281 | 1.51x |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| load-short-lines | singapore | 32912 | 262144 | 262144 |
| load-short-lines | vscode | 39800 | 160004 | 160004 |
| load-long-line | singapore | 34632 | 0 | 0 |
| load-long-line | vscode | 33936 | 0 | 0 |
| sequential-typing | singapore | 84200 | 65536 | 65536 |
| sequential-typing | vscode | 88832 | 40004 | 40004 |
| typing-with-lookups | singapore | 70112 | 66560 | 66560 |
| typing-with-lookups | vscode | 93864 | 40004 | 40004 |
| random-insertions | singapore | 833080 | 65536 | 65536 |
| random-insertions | vscode | 628432 | 40004 | 40004 |
| random-replacements | singapore | 1164992 | 65536 | 65536 |
| random-replacements | vscode | 659912 | 40004 | 40004 |
| eight-cursor-batches | singapore | 837024 | 65536 | 65536 |
| eight-cursor-batches | vscode | 607632 | 40004 | 40004 |
| mixed-edit-churn | singapore | 1023472 | 65536 | 65536 |
| mixed-edit-churn | vscode | 542912 | 40004 | 40004 |
| large-paste-delete | singapore | 602304 | 65536 | 65536 |
| large-paste-delete | vscode | 54560 | 972164 | 972164 |
| lines-sequential-after-churn | singapore | 1034224 | 66048 | 66048 |
| lines-sequential-after-churn | vscode | 541760 | 40004 | 40004 |
| lines-random-after-churn | singapore | 1034056 | 66048 | 66048 |
| lines-random-after-churn | vscode | 541880 | 40004 | 40004 |
| ranges-after-churn | singapore | 1019088 | 65536 | 65536 |
| ranges-after-churn | vscode | 517000 | 40004 | 40004 |
| offset-to-position | singapore | 1021144 | 66048 | 66048 |
| offset-to-position | vscode | 541872 | 40004 | 40004 |
| position-to-offset | singapore | 1021128 | 66048 | 66048 |
| position-to-offset | vscode | 544984 | 40004 | 40004 |
| full-read-after-churn | singapore | 1019088 | 65536 | 65536 |
| full-read-after-churn | vscode | 538840 | 40004 | 40004 |
| persistent-history | singapore | 3196496 | 65536 | 65536 |
| branch-edits | singapore | 1013096 | 65536 | 65536 |
| anchor-resolution-after-churn | singapore | 1030424 | 65536 | 65536 |
| anchor-density | singapore | 267424 | 65536 | 65536 |
| ascii-replacements | singapore | -556800 | 65536 | 65536 |
| ascii-replacements | vscode | 647152 | 40004 | 40004 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

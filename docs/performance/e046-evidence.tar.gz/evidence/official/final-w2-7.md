# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 2994378da48e31a0a047c155886dfdb49081ecfd.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| load-short-lines | 1 | 2.164 / 2.207 | 3.745 / 4.156 | 0.58x |
| load-long-line | 1 | 1.059 / 1.085 | 2.846 / 2.998 | 0.37x |
| sequential-typing | 1500 | 0.402 / 0.480 | 0.613 / 0.637 | 0.66x |
| typing-with-lookups | 3000 | 0.621 / 0.654 | 0.966 / 0.997 | 0.64x |
| random-insertions | 1500 | 1.401 / 1.914 | 1.095 / 1.170 | 1.28x |
| random-replacements | 1500 | 2.839 / 3.735 | 1.384 / 1.475 | 2.05x |
| eight-cursor-batches | 187 | 1.673 / 1.694 | 1.138 / 1.212 | 1.47x |
| mixed-edit-churn | 1500 | 2.356 / 2.937 | 1.152 / 1.367 | 2.05x |
| large-paste-delete | 32 | 4.657 / 4.761 | 12.669 / 12.861 | 0.37x |
| lines-sequential-after-churn | 3000 | 0.692 / 0.702 | 0.504 / 0.582 | 1.37x |
| lines-random-after-churn | 3000 | 0.930 / 0.963 | 0.760 / 0.777 | 1.22x |
| ranges-after-churn | 3000 | 1.307 / 1.408 | 3.042 / 3.127 | 0.43x |
| offset-to-position | 3000 | 0.771 / 0.783 | 1.621 / 1.685 | 0.48x |
| position-to-offset | 3000 | 0.593 / 0.601 | 0.404 / 0.431 | 1.47x |
| full-read-after-churn | 12 | 2.028 / 2.152 | 1.291 / 1.451 | 1.57x |
| persistent-history | 1500 | 2.543 / 2.566 | not equivalent | separate lane |
| branch-edits | 64 | 0.276 / 0.297 | not equivalent | separate lane |
| anchor-resolution-after-churn | 3000 | 0.494 / 0.502 | not equivalent | separate lane |
| anchor-density | 300 | 10.437 / 10.797 | not equivalent | separate lane |
| ascii-replacements | 1500 | 2.757 / 2.943 | 1.363 / 1.483 | 2.02x |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| load-short-lines | singapore | 8520 | 262144 | 262144 |
| load-short-lines | vscode | 7096 | 160004 | 160004 |
| load-long-line | singapore | 4272 | 0 | 0 |
| load-long-line | vscode | 7792 | 0 | 0 |
| sequential-typing | singapore | 67584 | 65536 | 65536 |
| sequential-typing | vscode | 89792 | 40004 | 40004 |
| typing-with-lookups | singapore | -21144 | 66560 | 66560 |
| typing-with-lookups | vscode | 90240 | 40004 | 40004 |
| random-insertions | singapore | 830712 | 65536 | 65536 |
| random-insertions | vscode | 625408 | 40004 | 40004 |
| random-replacements | singapore | 1175048 | 65536 | 65536 |
| random-replacements | vscode | 648480 | 40004 | 40004 |
| eight-cursor-batches | singapore | 820200 | 65536 | 65536 |
| eight-cursor-batches | vscode | 587856 | 40004 | 40004 |
| mixed-edit-churn | singapore | 1056360 | 65536 | 65536 |
| mixed-edit-churn | vscode | 549280 | 40004 | 40004 |
| large-paste-delete | singapore | 602792 | 65536 | 65536 |
| large-paste-delete | vscode | 55984 | 972164 | 972164 |
| lines-sequential-after-churn | singapore | 1050608 | 66048 | 66048 |
| lines-sequential-after-churn | vscode | 508816 | 40004 | 40004 |
| lines-random-after-churn | singapore | 1050560 | 66048 | 66048 |
| lines-random-after-churn | vscode | 512816 | 40004 | 40004 |
| ranges-after-churn | singapore | 1054400 | 65536 | 65536 |
| ranges-after-churn | vscode | 544264 | 40004 | 40004 |
| offset-to-position | singapore | 1047752 | 66048 | 66048 |
| offset-to-position | vscode | 533664 | 40004 | 40004 |
| position-to-offset | singapore | 1050840 | 66048 | 66048 |
| position-to-offset | vscode | 529736 | 40004 | 40004 |
| full-read-after-churn | singapore | 1046552 | 65536 | 65536 |
| full-read-after-churn | vscode | 521048 | 40004 | 40004 |
| persistent-history | singapore | 3240256 | 65536 | 65536 |
| branch-edits | singapore | 1041392 | 65536 | 65536 |
| anchor-resolution-after-churn | singapore | 1070816 | 65536 | 65536 |
| anchor-density | singapore | 321704 | 65536 | 65536 |
| ascii-replacements | singapore | 1230400 | 65536 | 65536 |
| ascii-replacements | vscode | 629576 | 40004 | 40004 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

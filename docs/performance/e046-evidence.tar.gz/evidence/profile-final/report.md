# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## random-replacements

1500 logical operations per replay.

### singapore

CPU: 421 in-workload samples; 63 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 326 | 77.4% |
| buffer store / line index | 64 | 15.2% |
| adapter / harness / other | 11 | 2.6% |
| edit preparation / boundary policy | 10 | 2.4% |
| reverse index | 10 | 2.4% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:254:applyBatchToPieceTable`: 92.9% of in-workload samples.
- `textbuffer/dist/edits.js:245:applyUnsnappedEdit`: 92.6% of in-workload samples.
- `textbuffer/dist/edits.js:203:applyOneEdit`: 89.5% of in-workload samples.
- `textbuffer/dist/edits.js:179:replaceUnsnappedRange`: 89.3% of in-workload samples.
- `textbuffer/dist/edits.js:153:hideRange`: 89.1% of in-workload samples.
- `textbuffer/dist/tree.js:334:hideVisibleRange`: 88.4% of in-workload samples.

Structure after workload: {"pieces":4437,"invisible":1520,"visible":2917,"maxDepth":15,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 187 | 0.12 |
| buffers.growTailLineIndex.indexInputCodeUnits | 3376 | 2.25 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| join.join.calls | 18974 | 12.65 |
| join.rotateLeft.calls | 796 | 0.53 |
| join.rotateRight.calls | 1125 | 0.75 |
| node.cloneNode.calls | 15859 | 10.57 |
| node.createNode.calls | 4436 | 2.96 |
| node.own.calls | 24013 | 16.01 |
| reverseIndex.appendSlot.calls | 1500 | 1.00 |
| reverseIndex.copyBranch.calls | 187 | 0.12 |
| reverseIndex.splitNode.calls | 24 | 0.02 |

### vscode

CPU: 296 in-workload samples; 43 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 198 | 66.9% |
| red-black tree | 89 | 30.1% |
| adapter / harness / other | 9 | 3.0% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 56.8% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 39.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 27.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 25.7% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 23.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:936:shrinkNode`: 22.3% of in-workload samples.

Structure after workload: {"pieces":2917,"invisible":0,"visible":2917,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 3380 | 2.25 |
| pieceTreeBase.createLineStartsFast.loopIterations | 3380 | 2.25 |
| rbTreeBase.leftRotate.calls | 1726 | 1.15 |
| rbTreeBase.rightRotate.calls | 1755 | 1.17 |
| rbTreeBase.TreeNode.constructor.calls | 2950 | 1.97 |

## mixed-edit-churn

1500 logical operations per replay.

### vscode

CPU: 246 in-workload samples; 53 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 163 | 66.3% |
| red-black tree | 74 | 30.1% |
| adapter / harness / other | 9 | 3.7% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 63.8% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 32.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:936:shrinkNode`: 28.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 26.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 22.0% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 21.1% of in-workload samples.

Structure after workload: {"pieces":2435,"invisible":0,"visible":2435,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 2260 | 1.51 |
| pieceTreeBase.createLineStartsFast.loopIterations | 2260 | 1.51 |
| rbTreeBase.leftRotate.calls | 823 | 0.55 |
| rbTreeBase.rightRotate.calls | 1197 | 0.80 |
| rbTreeBase.TreeNode.constructor.calls | 2453 | 1.64 |

### singapore

CPU: 429 in-workload samples; 59 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 314 | 73.2% |
| buffer store / line index | 63 | 14.7% |
| adapter / harness / other | 18 | 4.2% |
| reverse index | 18 | 4.2% |
| edit preparation / boundary policy | 16 | 3.7% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:179:replaceUnsnappedRange`: 77.9% of in-workload samples.
- `textbuffer/dist/edits.js:203:applyOneEdit`: 77.9% of in-workload samples.
- `textbuffer/dist/edits.js:153:hideRange`: 76.9% of in-workload samples.
- `textbuffer/dist/tree.js:334:hideVisibleRange`: 76.5% of in-workload samples.
- `textbuffer/dist/edits.js:254:applyBatchToPieceTable`: 65.7% of in-workload samples.
- `textbuffer/dist/edits.js:245:applyUnsnappedEdit`: 65.3% of in-workload samples.

Structure after workload: {"pieces":3915,"invisible":1480,"visible":2435,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 134 | 0.09 |
| buffers.growTailLineIndex.indexInputCodeUnits | 2259 | 1.51 |
| buffers.PieceBufferChunkView.fill.calls | 1004 | 0.67 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| join.join.calls | 17719 | 11.81 |
| join.rotateLeft.calls | 665 | 0.44 |
| join.rotateRight.calls | 957 | 0.64 |
| node.cloneNode.calls | 17905 | 11.94 |
| node.createNode.calls | 3914 | 2.61 |
| node.own.calls | 25060 | 16.71 |
| reverseIndex.appendSlot.calls | 1676 | 1.12 |
| reverseIndex.copyBranch.calls | 177 | 0.12 |
| reverseIndex.splitNode.calls | 14 | 0.01 |
| tree.normalizePieceOrders.calls | 5219 | 3.48 |

## lines-sequential-after-churn

3000 logical operations per replay.

### singapore

CPU: 122 in-workload samples; 64 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| adapter / harness / other | 53 | 43.4% |
| position lookup | 34 | 27.9% |
| piece tree | 25 | 20.5% |
| buffer store / line index | 10 | 8.2% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/reads.js:24:readPieceTableLine`: 64.8% of in-workload samples.
- `textbuffer/dist/positions.js:119:findLineRange`: 34.4% of in-workload samples.
- `textbuffer/dist/reads.js:14:readPieceTableTextRange`: 25.4% of in-workload samples.
- `textbuffer/dist/tree.js:386:collectTextInRange`: 21.3% of in-workload samples.
- `textbuffer/dist/buffers.js:254:pieceLineIndex`: 6.6% of in-workload samples.
- `textbuffer/dist/buffers.js:276:pieceLineBreakOffsets`: 6.6% of in-workload samples.

Structure after workload: {"pieces":3915,"invisible":1480,"visible":2435,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.extendBufferLineIndex.indexInputCodeUnits | 2260 | 0.75 |
| buffers.extendBufferLineIndex.loopIterations | 134 | 0.04 |
| buffers.pushLineBreakOffset.typedArrayCapacityBytes | 1792 | 0.60 |
| buffers.pushLineBreakOffset.typedArrayCopiedBytes | 768 | 0.26 |
| positions.findLineRange.calls | 3000 | 1.00 |
| reads.readPieceTableTextRange.calls | 375 | 0.13 |
| tree.collectTextInRange.calls | 5949 | 1.98 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

### vscode

CPU: 78 in-workload samples; 51 excluded. Fewer than 100 in-workload samples: increase --repeats; do not rank small shares.

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| adapter / harness / other | 45 | 57.7% |
| VS Code buffer / line index | 32 | 41.0% |
| red-black tree | 1 | 1.3% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:441:getLineContent`: 42.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:799:getLineRawContent`: 34.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:896:getAccumulatedValue`: 12.8% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:188:get2`: 2.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:727:offsetInBuffer`: 2.6% of in-workload samples.
- `vscode/dist/rbTreeBase.js:85:leftest`: 1.3% of in-workload samples.

Structure after workload: {"pieces":2435,"invisible":0,"visible":2435,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.PieceTreeBase.getLineContent.calls | 3000 | 1.00 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

## lines-random-after-churn

3000 logical operations per replay.

### vscode

CPU: 144 in-workload samples; 63 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 83 | 57.6% |
| adapter / harness / other | 59 | 41.0% |
| red-black tree | 2 | 1.4% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:441:getLineContent`: 59.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:799:getLineRawContent`: 56.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:197:set`: 10.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:896:getAccumulatedValue`: 6.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:188:get2`: 3.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:727:offsetInBuffer`: 1.4% of in-workload samples.

Structure after workload: {"pieces":2435,"invisible":0,"visible":2435,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.PieceTreeBase.getLineContent.cachedLineHits | 1 | 0.00 |
| pieceTreeBase.PieceTreeBase.getLineContent.calls | 3000 | 1.00 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

### singapore

CPU: 206 in-workload samples; 54 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| position lookup | 96 | 46.6% |
| adapter / harness / other | 83 | 40.3% |
| piece tree | 18 | 8.7% |
| buffer store / line index | 9 | 4.4% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/reads.js:24:readPieceTableLine`: 68.4% of in-workload samples.
- `textbuffer/dist/positions.js:119:findLineRange`: 48.5% of in-workload samples.
- `textbuffer/dist/reads.js:14:readPieceTableTextRange`: 17.0% of in-workload samples.
- `textbuffer/dist/tree.js:386:collectTextInRange`: 10.7% of in-workload samples.
- `textbuffer/dist/node.js:5:getSubtreeLineBreaks`: 8.3% of in-workload samples.
- `textbuffer/dist/node.js:9:getPieceVisibleLineBreaks`: 5.3% of in-workload samples.

Structure after workload: {"pieces":3915,"invisible":1480,"visible":2435,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.extendBufferLineIndex.indexInputCodeUnits | 2260 | 0.75 |
| buffers.extendBufferLineIndex.loopIterations | 134 | 0.04 |
| buffers.pushLineBreakOffset.typedArrayCapacityBytes | 1792 | 0.60 |
| buffers.pushLineBreakOffset.typedArrayCopiedBytes | 768 | 0.26 |
| positions.findLineRange.calls | 3000 | 1.00 |
| reads.readPieceTableTextRange.calls | 411 | 0.14 |
| tree.collectTextInRange.calls | 6552 | 2.18 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

## position-to-offset

3000 logical operations per replay.

### singapore

CPU: 121 in-workload samples; 51 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| position lookup | 87 | 71.9% |
| adapter / harness / other | 27 | 22.3% |
| buffer store / line index | 7 | 5.8% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/positions.js:190:pointToOffset`: 77.7% of in-workload samples.
- `textbuffer/dist/positions.js:119:findLineRange`: 71.1% of in-workload samples.
- `textbuffer/dist/node.js:5:getSubtreeLineBreaks`: 12.4% of in-workload samples.
- `textbuffer/dist/node.js:9:getPieceVisibleLineBreaks`: 8.3% of in-workload samples.
- `textbuffer/dist/buffers.js:254:pieceLineIndex`: 5.8% of in-workload samples.
- `textbuffer/dist/buffers.js:276:pieceLineBreakOffsets`: 5.8% of in-workload samples.

Structure after workload: {"pieces":3915,"invisible":1480,"visible":2435,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.extendBufferLineIndex.indexInputCodeUnits | 2260 | 0.75 |
| buffers.extendBufferLineIndex.loopIterations | 134 | 0.04 |
| buffers.pushLineBreakOffset.typedArrayCapacityBytes | 1792 | 0.60 |
| buffers.pushLineBreakOffset.typedArrayCopiedBytes | 768 | 0.26 |
| positions.findLineRange.calls | 3000 | 1.00 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

### vscode

CPU: 81 in-workload samples; 46 excluded. Fewer than 100 in-workload samples: increase --repeats; do not rank small shares.

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 61 | 75.3% |
| adapter / harness / other | 20 | 24.7% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:326:getOffsetAt`: 75.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:896:getAccumulatedValue`: 16.0% of in-workload samples.

Structure after workload: {"pieces":2435,"invisible":0,"visible":2435,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.PieceTreeBase.getOffsetAt.calls | 3000 | 1.00 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

## ascii-replacements

1500 logical operations per replay.

### vscode

CPU: 297 in-workload samples; 54 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 197 | 66.3% |
| red-black tree | 90 | 30.3% |
| adapter / harness / other | 10 | 3.4% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 55.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 41.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 28.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 21.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:936:shrinkNode`: 21.5% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 21.2% of in-workload samples.

Structure after workload: {"pieces":2910,"invisible":0,"visible":2910,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 3186 | 2.12 |
| pieceTreeBase.createLineStartsFast.loopIterations | 3186 | 2.12 |
| rbTreeBase.leftRotate.calls | 1707 | 1.14 |
| rbTreeBase.rightRotate.calls | 1753 | 1.17 |
| rbTreeBase.TreeNode.constructor.calls | 2948 | 1.97 |

### singapore

CPU: 382 in-workload samples; 60 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 307 | 80.4% |
| buffer store / line index | 50 | 13.1% |
| edit preparation / boundary policy | 11 | 2.9% |
| reverse index | 7 | 1.8% |
| adapter / harness / other | 7 | 1.8% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:254:applyBatchToPieceTable`: 93.7% of in-workload samples.
- `textbuffer/dist/edits.js:245:applyUnsnappedEdit`: 93.2% of in-workload samples.
- `textbuffer/dist/edits.js:203:applyOneEdit`: 90.6% of in-workload samples.
- `textbuffer/dist/edits.js:153:hideRange`: 90.3% of in-workload samples.
- `textbuffer/dist/tree.js:334:hideVisibleRange`: 89.8% of in-workload samples.
- `textbuffer/dist/tree.js:261:hidePieceRange`: 46.9% of in-workload samples.

Structure after workload: {"pieces":4427,"invisible":1517,"visible":2910,"maxDepth":15,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 188 | 0.13 |
| buffers.growTailLineIndex.indexInputCodeUnits | 3185 | 2.12 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| join.join.calls | 18943 | 12.63 |
| join.rotateLeft.calls | 789 | 0.53 |
| join.rotateRight.calls | 1123 | 0.75 |
| node.cloneNode.calls | 15921 | 10.61 |
| node.createNode.calls | 4426 | 2.95 |
| node.own.calls | 24228 | 16.15 |
| reverseIndex.appendSlot.calls | 1500 | 1.00 |
| reverseIndex.copyBranch.calls | 180 | 0.12 |
| reverseIndex.splitNode.calls | 18 | 0.01 |

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

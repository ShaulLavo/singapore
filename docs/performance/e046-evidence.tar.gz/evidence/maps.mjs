import path from 'node:path'
import { readFileSync } from 'node:fs'
const [root, benchDir] = process.argv.slice(2)
const { loadAdapter, applyOperation } = await import(path.join(benchDir, 'adapters.mjs'))
const fixture = JSON.parse(readFileSync(new URL('fixtures/20260916-anchor-density.json', import.meta.url), 'utf8'))
const factory = await loadAdapter('singapore', { singapore: root })
const { flattenNodes } = await import(path.join(root, 'tree.js'))
for (let round = 0; round < 3; round += 1) {
  const buffer = factory.create(fixture.initial)
  for (const op of fixture.operations) applyOperation(buffer, op)
  const pieces = flattenNodes(buffer.snapshot.root, []).map((n) => n.piece)
  const groups = []
  for (const p of pieces) { const g = groups.find((g) => %HaveSameMap(g[0], p)); if (g) g.push(p); else groups.push([p]) }
  console.log('round', round, 'pieces', pieces.length, 'maps', groups.map((g) => g.length))
  if (round === 2) for (const g of groups) { %DebugPrint(g[0]) }
}

// node editor-bench.mjs <label> <runs>: medians of the editor's two benches
import { execFileSync } from 'node:child_process'
import { writeFileSync } from 'node:fs'
const [label, runs] = process.argv.slice(2)
const cwd = '/work/projects/Editor/packages/editor'
const median = (v) => v.toSorted((a, b) => a - b)[v.length >> 1]
const rows = new Map()
const add = (key, ms) => rows.set(key, [...(rows.get(key) ?? []), ms])
for (let run = 0; run < Number(runs); run += 1)
  for (const script of ['bench:virtualization', 'bench:walker']) {
    const out = execFileSync('bun', ['run', script], { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })
    let title = ''
    for (const line of out.split('\n')) {
      if (line.startsWith('{"name"')) { const r = JSON.parse(line); add(`${script} ${r.name} ${r.lines ?? ''}`, r.durationMs ?? r.ms ?? r.medianMs) ; continue }
      const head = /^(.*) benchmark$/.exec(line); if (head) title = head[1]
      const d = /^duration: ([\d.]+)ms/.exec(line); if (d) add(`${script} ${title}`, Number(d[1]))
      const w = /^(\s*)([^:]+): ([\d.]+)ms$/.exec(line); if (w && script === 'bench:walker') add(`${script} ${w[1] ? title + ' / ' : ''}${w[2]}`, Number(w[3]))
      const section = /^walker benchmark: (.*)$/.exec(line); if (section) title = section[1]
    }
    if (run === 0 && script === 'bench:walker') writeFileSync(`/work/tmp/e046/walker-${label}.txt`, out)
  }
const result = Object.fromEntries([...rows].map(([k, v]) => [k, Number(median(v).toFixed(3))]))
writeFileSync(`/work/tmp/e046/editor-bench-${label}.json`, JSON.stringify(result, null, 2))
console.log(result)

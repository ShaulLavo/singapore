import { writeFileSync, mkdirSync } from 'node:fs'
const { makeFixtures } = await import('/work/projects/Editor/packages/textbuffer/bench/fixtures.mjs')
const dir = new URL('fixtures/', import.meta.url).pathname
mkdirSync(dir, { recursive: true })
for (const seed of [20260916, 7, 12345, 42, 99])
  for (const fixture of makeFixtures('standard', seed))
    writeFileSync(`${dir}${seed}-${fixture.name}.json`, JSON.stringify(fixture))

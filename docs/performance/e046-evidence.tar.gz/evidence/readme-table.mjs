// node readme-table.mjs: README rows from the official runs, each regime against its own control
import { readFileSync } from 'node:fs'
const seeds = [20260916, 7, 12345]
const median = (v) => v.toSorted((a, b) => a - b)[v.length >> 1]
const load = (w) => {
  const lanes = new Map()
  for (const seed of seeds)
    for (const x of JSON.parse(readFileSync(`/work/tmp/e046/final-w${w}-${seed}.json`)).workloads) {
      const row = lanes.get(x.name) ?? { s: [], c: [] }
      lanes.set(x.name, row)
      row.s.push(x.engines.singapore.timeMs.median)
      if (x.engines.vscode) row.c.push(x.engines.vscode.timeMs.median)
    }
  return new Map([...lanes].map(([k, v]) => [k, { s: median(v.s), c: v.c.length ? median(v.c) : null }]))
}
const w2 = load(2), w8 = load(8)
const work = {
  'load-short-lines': [1, '1 load of 1,520,000 code units'], 'load-long-line': [1, '1 load of 1,280,000 code units'],
  'sequential-typing': [1500, '1,500 keystrokes'], 'typing-with-lookups': [3000, '3,000 operations: 1,500 keystrokes, a caret lookup after each'],
  'random-insertions': [1500, '1,500 inserts'], 'random-replacements': [1500, '1,500 replacements'],
  'eight-cursor-batches': [187, '187 batches of 8 edits'], 'mixed-edit-churn': [1500, '1,500 mixed edits'],
  'large-paste-delete': [32, '32 operations: 16 pastes of about 256,000 code units, each then deleted'],
  'lines-sequential-after-churn': [3000, '3,000 line reads'], 'lines-random-after-churn': [3000, '3,000 line reads'],
  'ranges-after-churn': [3000, '3,000 offset-range reads'], 'offset-to-position': [3000, '3,000 conversions'],
  'position-to-offset': [3000, '3,000 conversions'], 'full-read-after-churn': [12, '12 full reads'],
  'ascii-replacements': [1500, '1,500 replacements of an ASCII-only document'],
  'persistent-history': [1500, '1,500 edits retaining up to 64 roots'], 'branch-edits': [64, '64 branches from one churned root, one insert each'],
  'anchor-resolution-after-churn': [3000, '3,000 resolutions across 128 anchors'], 'anchor-density': [300, '300 edits, all 500 anchors resolved after each'],
}
const per = (ms, ops) => (ops === 1 ? `${ms.toFixed(2)} ms` : `${((ms * 1000) / ops).toFixed(2)} µs`)
console.log('| Lane | Work per run | Control (ms) | Singapore (ms) | Per operation | Ratio | Ratio, 8 warmups |\n| --- | --- | ---: | ---: | ---: | ---: | ---: |')
for (const [lane, r] of w2) if (r.c) console.log(`| ${lane} | ${work[lane][1]} | ${r.c.toFixed(2)} | ${r.s.toFixed(2)} | ${per(r.s, work[lane][0])} | ${(r.s / r.c).toFixed(2)}x | ${(w8.get(lane).s / w8.get(lane).c).toFixed(2)}x |`)
console.log('\n| Lane | Work per run | Singapore (ms) | Per operation | 8 warmups (ms) |\n| --- | --- | ---: | ---: | ---: |')
for (const [lane, r] of w2) if (!r.c) console.log(`| ${lane} | ${work[lane][1]} | ${r.s.toFixed(2)} | ${per(r.s, work[lane][0])} | ${w8.get(lane).s.toFixed(2)} |`)
console.log('\n8-warmup ms (control, singapore):'); for (const [lane, r] of w8) console.log(lane, r.c?.toFixed(2) ?? '—', r.s.toFixed(2))

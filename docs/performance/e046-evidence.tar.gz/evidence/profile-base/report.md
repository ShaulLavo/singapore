# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## random-replacements

1500 logical operations per replay.

### singapore

CPU: 530 in-workload samples; 57 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 292 | 55.1% |
| buffer store / line index | 113 | 21.3% |
| adapter / harness / other | 95 | 17.9% |
| edit preparation / boundary policy | 21 | 4.0% |
| reverse index | 9 | 1.7% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:206:applyBatchToPieceTable`: 94.2% of in-workload samples.
- `textbuffer/dist/edits.js:158:replaceRange`: 73.6% of in-workload samples.
- `textbuffer/dist/tree.js:296:hideVisibleRange`: 72.8% of in-workload samples.
- `textbuffer/dist/tree.js:258:hidePieceRange`: 46.6% of in-workload samples.
- `textbuffer/dist/join.js:61:join`: 21.5% of in-workload samples.
- `textbuffer/dist/tree.js:266:count`: 18.5% of in-workload samples.

Structure after workload: {"pieces":4437,"invisible":1520,"visible":2917,"maxDepth":15,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 187 | 0.12 |
| buffers.growTailLineIndex.indexInputCodeUnits | 3376 | 2.25 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| edits.snapEditRange.calls | 1453 | 0.97 |
| join.join.calls | 18969 | 12.65 |
| join.rotateLeft.calls | 797 | 0.53 |
| join.rotateRight.calls | 1126 | 0.75 |
| node.cloneNode.calls | 15859 | 10.57 |
| node.createNode.calls | 4436 | 2.96 |
| node.own.calls | 24017 | 16.01 |
| reads.splitsSurrogatePair.calls | 2906 | 1.94 |
| reverseIndex.appendSlot.calls | 1500 | 1.00 |
| reverseIndex.copyBranch.calls | 187 | 0.12 |
| reverseIndex.splitNode.calls | 24 | 0.02 |

### vscode

CPU: 295 in-workload samples; 50 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 198 | 67.1% |
| red-black tree | 89 | 30.2% |
| adapter / harness / other | 8 | 2.7% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 55.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 41.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 28.8% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 26.1% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 22.7% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:936:shrinkNode`: 21.4% of in-workload samples.

Structure after workload: {"pieces":2917,"invisible":0,"visible":2917,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 3380 | 2.25 |
| pieceTreeBase.createLineStartsFast.loopIterations | 3380 | 2.25 |
| rbTreeBase.leftRotate.calls | 1726 | 1.15 |
| rbTreeBase.rightRotate.calls | 1755 | 1.17 |
| rbTreeBase.TreeNode.constructor.calls | 2950 | 1.97 |

## mixed-edit-churn

1500 logical operations per replay.

### vscode

CPU: 246 in-workload samples; 48 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 165 | 67.1% |
| red-black tree | 71 | 28.9% |
| adapter / harness / other | 10 | 4.1% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 64.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 31.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:936:shrinkNode`: 25.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 23.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 21.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 21.5% of in-workload samples.

Structure after workload: {"pieces":2435,"invisible":0,"visible":2435,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 2260 | 1.51 |
| pieceTreeBase.createLineStartsFast.loopIterations | 2260 | 1.51 |
| rbTreeBase.leftRotate.calls | 823 | 0.55 |
| rbTreeBase.rightRotate.calls | 1197 | 0.80 |
| rbTreeBase.TreeNode.constructor.calls | 2453 | 1.64 |

### singapore

CPU: 555 in-workload samples; 59 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 322 | 58.0% |
| buffer store / line index | 114 | 20.5% |
| adapter / harness / other | 96 | 17.3% |
| reverse index | 13 | 2.3% |
| edit preparation / boundary policy | 10 | 1.8% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:158:replaceRange`: 69.2% of in-workload samples.
- `textbuffer/dist/tree.js:296:hideVisibleRange`: 69.0% of in-workload samples.
- `textbuffer/dist/edits.js:206:applyBatchToPieceTable`: 68.8% of in-workload samples.
- `textbuffer/dist/tree.js:258:hidePieceRange`: 37.7% of in-workload samples.
- `textbuffer/dist/edits.js:184:deleteFromPieceTable`: 24.0% of in-workload samples.
- `textbuffer/dist/join.js:61:join`: 20.0% of in-workload samples.

Structure after workload: {"pieces":3915,"invisible":1480,"visible":2435,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 134 | 0.09 |
| buffers.growTailLineIndex.indexInputCodeUnits | 2259 | 1.51 |
| buffers.PieceBufferChunkView.fill.calls | 1004 | 0.67 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| edits.snapEditRange.calls | 1436 | 0.96 |
| join.join.calls | 17717 | 11.81 |
| join.rotateLeft.calls | 665 | 0.44 |
| join.rotateRight.calls | 957 | 0.64 |
| node.cloneNode.calls | 17905 | 11.94 |
| node.createNode.calls | 3914 | 2.61 |
| node.own.calls | 25062 | 16.71 |
| reads.splitsSurrogatePair.calls | 2872 | 1.91 |
| reverseIndex.appendSlot.calls | 1676 | 1.12 |
| reverseIndex.copyBranch.calls | 177 | 0.12 |
| reverseIndex.splitNode.calls | 14 | 0.01 |
| tree.normalizePieceOrders.calls | 5219 | 3.48 |

## lines-sequential-after-churn

3000 logical operations per replay.

### singapore

CPU: 279 in-workload samples; 50 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| position lookup | 92 | 33.0% |
| adapter / harness / other | 81 | 29.0% |
| piece tree | 71 | 25.4% |
| buffer store / line index | 35 | 12.5% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/positions.js:69:lineStartOffset`: 44.8% of in-workload samples.
- `textbuffer/dist/positions.js:52:findOffsetAfterLineBreak`: 44.4% of in-workload samples.
- `textbuffer/dist/reads.js:13:readPieceTableTextRange`: 38.0% of in-workload samples.
- `textbuffer/dist/tree.js:333:collectTextInRange`: 26.2% of in-workload samples.
- `textbuffer/dist/buffers.js:246:findBufferLineBreakOffset`: 11.8% of in-workload samples.
- `textbuffer/dist/positions.js:10:findOffsetAfterPieceLineBreak`: 11.8% of in-workload samples.

Structure after workload: {"pieces":3915,"invisible":1480,"visible":2435,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.extendBufferLineIndex.indexInputCodeUnits | 2260 | 0.75 |
| buffers.extendBufferLineIndex.loopIterations | 134 | 0.04 |
| buffers.pushLineBreakOffset.typedArrayCapacityBytes | 1792 | 0.60 |
| buffers.pushLineBreakOffset.typedArrayCopiedBytes | 768 | 0.26 |
| positions.lineStartOffset.calls | 6000 | 2.00 |
| reads.readPieceTableTextRange.calls | 3000 | 1.00 |
| tree.collectTextInRange.calls | 34070 | 11.36 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

### vscode

CPU: 74 in-workload samples; 50 excluded. Fewer than 100 in-workload samples: increase --repeats; do not rank small shares.

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 36 | 48.6% |
| adapter / harness / other | 35 | 47.3% |
| red-black tree | 3 | 4.1% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:441:getLineContent`: 52.7% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:799:getLineRawContent`: 44.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:896:getAccumulatedValue`: 17.6% of in-workload samples.
- `vscode/dist/rbTreeBase.js:37:next`: 4.1% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:188:get2`: 4.1% of in-workload samples.
- `vscode/dist/rbTreeBase.js:85:leftest`: 2.7% of in-workload samples.

Structure after workload: {"pieces":2435,"invisible":0,"visible":2435,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.PieceTreeBase.getLineContent.calls | 3000 | 1.00 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

## lines-random-after-churn

3000 logical operations per replay.

### vscode

CPU: 156 in-workload samples; 62 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 81 | 51.9% |
| adapter / harness / other | 73 | 46.8% |
| red-black tree | 2 | 1.3% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:441:getLineContent`: 53.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:799:getLineRawContent`: 51.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:197:set`: 7.7% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:896:getAccumulatedValue`: 5.1% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:188:get2`: 3.2% of in-workload samples.
- `vscode/dist/rbTreeBase.js:85:leftest`: 1.3% of in-workload samples.

Structure after workload: {"pieces":2435,"invisible":0,"visible":2435,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.PieceTreeBase.getLineContent.cachedLineHits | 1 | 0.00 |
| pieceTreeBase.PieceTreeBase.getLineContent.calls | 3000 | 1.00 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

### singapore

CPU: 445 in-workload samples; 66 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| position lookup | 163 | 36.6% |
| piece tree | 106 | 23.8% |
| adapter / harness / other | 101 | 22.7% |
| buffer store / line index | 75 | 16.9% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/positions.js:69:lineStartOffset`: 51.7% of in-workload samples.
- `textbuffer/dist/positions.js:52:findOffsetAfterLineBreak`: 51.0% of in-workload samples.
- `textbuffer/dist/reads.js:13:readPieceTableTextRange`: 32.4% of in-workload samples.
- `textbuffer/dist/tree.js:333:collectTextInRange`: 25.6% of in-workload samples.
- `textbuffer/dist/positions.js:10:findOffsetAfterPieceLineBreak`: 15.5% of in-workload samples.
- `textbuffer/dist/buffers.js:246:findBufferLineBreakOffset`: 15.1% of in-workload samples.

Structure after workload: {"pieces":3915,"invisible":1480,"visible":2435,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.extendBufferLineIndex.indexInputCodeUnits | 2260 | 0.75 |
| buffers.extendBufferLineIndex.loopIterations | 134 | 0.04 |
| buffers.pushLineBreakOffset.typedArrayCapacityBytes | 1792 | 0.60 |
| buffers.pushLineBreakOffset.typedArrayCopiedBytes | 768 | 0.26 |
| positions.lineStartOffset.calls | 6000 | 2.00 |
| reads.readPieceTableTextRange.calls | 3000 | 1.00 |
| tree.collectTextInRange.calls | 34835 | 11.61 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

## position-to-offset

3000 logical operations per replay.

### singapore

CPU: 237 in-workload samples; 48 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| position lookup | 163 | 68.8% |
| buffer store / line index | 48 | 20.3% |
| adapter / harness / other | 26 | 11.0% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/positions.js:90:pointToOffset`: 89.0% of in-workload samples.
- `textbuffer/dist/positions.js:52:findOffsetAfterLineBreak`: 83.5% of in-workload samples.
- `textbuffer/dist/positions.js:69:lineStartOffset`: 47.7% of in-workload samples.
- `textbuffer/dist/positions.js:75:lineEndOffset`: 40.5% of in-workload samples.
- `textbuffer/dist/positions.js:10:findOffsetAfterPieceLineBreak`: 21.1% of in-workload samples.
- `textbuffer/dist/buffers.js:246:findBufferLineBreakOffset`: 20.3% of in-workload samples.

Structure after workload: {"pieces":3915,"invisible":1480,"visible":2435,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.extendBufferLineIndex.indexInputCodeUnits | 2260 | 0.75 |
| buffers.extendBufferLineIndex.loopIterations | 134 | 0.04 |
| buffers.pushLineBreakOffset.typedArrayCapacityBytes | 1792 | 0.60 |
| buffers.pushLineBreakOffset.typedArrayCopiedBytes | 768 | 0.26 |
| positions.lineStartOffset.calls | 3000 | 1.00 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

### vscode

CPU: 79 in-workload samples; 47 excluded. Fewer than 100 in-workload samples: increase --repeats; do not rank small shares.

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 60 | 75.9% |
| adapter / harness / other | 19 | 24.1% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:326:getOffsetAt`: 75.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:896:getAccumulatedValue`: 5.1% of in-workload samples.

Structure after workload: {"pieces":2435,"invisible":0,"visible":2435,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.PieceTreeBase.getOffsetAt.calls | 3000 | 1.00 |

A second same-buffer query pass is recorded separately in JSON to expose cache warming.

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

// node selfshare.mjs <report.json>...: self-time shares of the functions E046 names
import { readFileSync } from 'node:fs'
const names = ['firstLineBreakAtOrAfter', 'splitsSurrogatePair', 'findOffsetAfterLineBreak', 'findLineRange', 'countPieceLineBreaksBefore', 'pieceLineIndex', 'collectTextInRange', 'snappedCut', 'endAt']
for (const file of process.argv.slice(2)) {
  console.log('##', file)
  for (const w of JSON.parse(readFileSync(file)).workloads) {
    const cpu = w.engines.singapore?.cpu?.cpu
    if (!cpu) continue
    const total = cpu.samples
    const cells = names.map((n) => { const v = cpu.self.filter((s) => s.name.includes(n)).reduce((a, s) => a + s.value, 0); return v ? `${n} ${(100 * v / total).toFixed(1)}%` : null }).filter(Boolean)
    console.log(w.name.padEnd(30), `samples ${total}`, `median ${w.engines.singapore.cpu.diagnosticTimeMs.median.toFixed(2)}ms |`, cells.join(', '))
  }
}

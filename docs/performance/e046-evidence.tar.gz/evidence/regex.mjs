const SURROGATE = /[\ud800-\udfff]/
const time = (label, text) => { for (let i=0;i<5;i++) SURROGATE.test(text); const t=performance.now(); let r; for (let i=0;i<20;i++) r=SURROGATE.test(text); console.log(label, ((performance.now()-t)/20).toFixed(4),'ms', r, text.length) }
time('ascii 1.5M', 'const value = "hello world"; // text\n'.repeat(41000))
time('two-byte no surrogates 1.5M', 'const value = "שלום é 中"; // text\n'.repeat(41000))
time('fixture-like 1.5M', 'const value = "שלום 😀 é 中"; // text\n'.repeat(40000))
const loop = (text) => { for (let i=0;i<text.length;i++){ const c=text.charCodeAt(i); if (c>=0xd800&&c<=0xdfff) return true } return false }
const t2 = 'const value = "שלום é 中"; // text\n'.repeat(41000)
for (let i=0;i<5;i++) loop(t2); let t=performance.now(); for (let i=0;i<20;i++) loop(t2); console.log('loop two-byte', ((performance.now()-t)/20).toFixed(4))

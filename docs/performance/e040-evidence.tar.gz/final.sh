#!/bin/bash
LANES=random-insertions,random-replacements,eight-cursor-batches,mixed-edit-churn,sequential-typing,typing-with-lookups,large-paste-delete,persistent-history,branch-edits,anchor-resolution-after-churn,lines-random-after-churn,lines-sequential-after-churn,ranges-after-churn,full-read-after-churn,offset-to-position,position-to-offset,load-short-lines,load-long-line
OUT=/work/tmp/e040-timing/final; mkdir -p $OUT
for seed in 20260916 7 12345; do
  for which in treap final; do
    if [ $which = treap ]; then dir=/work/worktrees/Editor/e040-before; else dir=/work/projects/Editor; fi
    cd $dir/packages/textbuffer
    echo "=== $which seed $seed $(date +%T)"
    bun run bench -- --profile standard --seed $seed --only $LANES --output $OUT/$which-$seed.json 2>&1 | grep -E "Results|rror"
  done
done
cd /work/projects/Editor/packages/textbuffer
echo "=== profile $(date +%T)"
bun run bench:profile -- --profile standard --only random-insertions,random-replacements --modes cpu,counters --repeats 24 --out $OUT/profile 2>&1 | tail -3
echo "=== height $(date +%T)"
bun run bench:height -- --profile standard --out $OUT/height 2>&1 | tail -2
echo E040-FINAL-DONE

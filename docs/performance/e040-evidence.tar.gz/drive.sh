#!/bin/bash
# E040 bake-off: every configuration on every seed, interleaved so drift hits all alike.
LANES=random-insertions,random-replacements,eight-cursor-batches,mixed-edit-churn,sequential-typing,typing-with-lookups,large-paste-delete,persistent-history,branch-edits,anchor-resolution-after-churn,lines-random-after-churn,lines-sequential-after-churn,ranges-after-churn,full-read-after-churn,offset-to-position,position-to-offset
OUT=/work/tmp/e040-timing
run() { # name dir balance alpha edits seed
  cd $2/packages/textbuffer
  echo "=== $1 seed $6 $(date +%T)"
  TEXTBUFFER_BALANCE=$3 TEXTBUFFER_ALPHA=$4 TEXTBUFFER_EDITS=$5 bun run bench -- --profile standard --seed $6 --only $LANES --output $OUT/$1-$6.json 2>&1 | grep -E "Results|rror"
}
B=/work/worktrees/Editor/e040-bakeoff
for seed in 20260916 7 12345; do
  run treap /work/worktrees/Editor/e040-before x x x $seed
  run avl-split $B avl 0.29 split $seed
  run avl-direct $B avl 0.29 direct $seed
  run wb29-split $B wb 0.29 split $seed
  run wb29-direct $B wb 0.29 direct $seed
  run wb25-direct $B wb 0.25 direct $seed
  run wb20-direct $B wb 0.2 direct $seed
done
echo E040-BAKEOFF-DONE

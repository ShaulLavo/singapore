# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 55c4ceafb8b54ebaf5a61d5cd15c2ab63298824f.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| load-short-lines | 1 | 2.164 / 2.248 | 3.778 / 3.884 | 0.57x |
| load-long-line | 1 | 1.074 / 1.094 | 2.838 / 2.973 | 0.38x |
| sequential-typing | 1500 | 0.513 / 0.530 | 0.613 / 0.663 | 0.84x |
| typing-with-lookups | 3000 | 0.730 / 0.741 | 0.953 / 1.001 | 0.77x |
| random-insertions | 1500 | 2.986 / 3.147 | 1.072 / 1.185 | 2.79x |
| random-replacements | 1500 | 6.136 / 6.370 | 1.358 / 1.461 | 4.52x |
| eight-cursor-batches | 187 | 3.440 / 3.553 | 1.164 / 1.218 | 2.95x |
| mixed-edit-churn | 1500 | 5.061 / 5.112 | 1.147 / 1.235 | 4.41x |
| large-paste-delete | 32 | 4.625 / 4.683 | 12.535 / 12.769 | 0.37x |
| lines-sequential-after-churn | 3000 | 1.536 / 1.577 | 0.485 / 0.695 | 3.17x |
| lines-random-after-churn | 3000 | 2.166 / 2.185 | 0.742 / 0.818 | 2.92x |
| ranges-after-churn | 3000 | 1.472 / 1.491 | 3.037 / 3.090 | 0.48x |
| offset-to-position | 3000 | 1.317 / 1.393 | 1.602 / 1.694 | 0.82x |
| position-to-offset | 3000 | 1.214 / 1.274 | 0.393 / 0.424 | 3.09x |
| full-read-after-churn | 12 | 2.225 / 2.283 | 1.324 / 1.374 | 1.68x |
| persistent-history | 1500 | 5.109 / 7.814 | not equivalent | separate lane |
| branch-edits | 64 | 0.333 / 0.338 | not equivalent | separate lane |
| anchor-resolution-after-churn | 3000 | 0.778 / 0.797 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| load-short-lines | singapore | 8416 | 262144 | 262144 |
| load-short-lines | vscode | 7096 | 160004 | 160004 |
| load-long-line | singapore | 4168 | 0 | 0 |
| load-long-line | vscode | 7792 | 0 | 0 |
| sequential-typing | singapore | 77824 | 65536 | 65536 |
| sequential-typing | vscode | 89176 | 40004 | 40004 |
| typing-with-lookups | singapore | 71136 | 66560 | 66560 |
| typing-with-lookups | vscode | 89592 | 40004 | 40004 |
| random-insertions | singapore | -434352 | 65536 | 65536 |
| random-insertions | vscode | 617032 | 40004 | 40004 |
| random-replacements | singapore | -834728 | 66560 | 66560 |
| random-replacements | vscode | 647864 | 40004 | 40004 |
| eight-cursor-batches | singapore | -437264 | 66560 | 66560 |
| eight-cursor-batches | vscode | 587944 | 40004 | 40004 |
| mixed-edit-churn | singapore | -349720 | 66048 | 66048 |
| mixed-edit-churn | vscode | 543576 | 40004 | 40004 |
| large-paste-delete | singapore | 615296 | 65536 | 65536 |
| large-paste-delete | vscode | 56056 | 972164 | 972164 |
| lines-sequential-after-churn | singapore | 1356312 | 66048 | 66048 |
| lines-sequential-after-churn | vscode | 508600 | 40004 | 40004 |
| lines-random-after-churn | singapore | 1356240 | 66048 | 66048 |
| lines-random-after-churn | vscode | 512520 | 40004 | 40004 |
| ranges-after-churn | singapore | 1356800 | 66048 | 66048 |
| ranges-after-churn | vscode | 545368 | 40004 | 40004 |
| offset-to-position | singapore | 1356392 | 66048 | 66048 |
| offset-to-position | vscode | 532616 | 40004 | 40004 |
| position-to-offset | singapore | 1356360 | 66048 | 66048 |
| position-to-offset | vscode | 524128 | 40004 | 40004 |
| full-read-after-churn | singapore | 1349120 | 66048 | 66048 |
| full-read-after-churn | vscode | 516640 | 40004 | 40004 |
| persistent-history | singapore | 4043888 | 66048 | 66048 |
| branch-edits | singapore | -345872 | 66048 | 66048 |
| anchor-resolution-after-churn | singapore | 1432896 | 66048 | 66048 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

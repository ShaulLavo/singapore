# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: c9ad15d096a62c0bb37ff36cac358fae7c9a0105.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| load-short-lines | 1 | 2.123 / 2.188 | 3.770 / 4.137 | 0.56x |
| load-long-line | 1 | 1.072 / 1.131 | 2.856 / 3.050 | 0.38x |
| sequential-typing | 1500 | 0.425 / 0.445 | 0.611 / 0.649 | 0.70x |
| typing-with-lookups | 3000 | 0.629 / 0.715 | 0.943 / 0.985 | 0.67x |
| random-insertions | 1500 | 2.358 / 2.502 | 1.124 / 1.209 | 2.10x |
| random-replacements | 1500 | 4.056 / 4.220 | 1.359 / 1.447 | 2.99x |
| eight-cursor-batches | 187 | 2.703 / 2.780 | 1.183 / 1.242 | 2.29x |
| mixed-edit-churn | 1500 | 3.747 / 3.881 | 1.153 / 1.350 | 3.25x |
| large-paste-delete | 32 | 4.702 / 5.322 | 12.745 / 12.866 | 0.37x |
| lines-sequential-after-churn | 3000 | 1.318 / 1.341 | 0.492 / 0.575 | 2.68x |
| lines-random-after-churn | 3000 | 1.995 / 2.040 | 0.758 / 0.802 | 2.63x |
| ranges-after-churn | 3000 | 1.340 / 1.384 | 3.017 / 3.035 | 0.44x |
| offset-to-position | 3000 | 1.237 / 1.254 | 1.605 / 1.628 | 0.77x |
| position-to-offset | 3000 | 1.132 / 1.141 | 0.390 / 0.408 | 2.90x |
| full-read-after-churn | 12 | 1.997 / 2.117 | 1.289 / 1.412 | 1.55x |
| persistent-history | 1500 | 3.806 / 4.139 | not equivalent | separate lane |
| branch-edits | 64 | 0.309 / 0.370 | not equivalent | separate lane |
| anchor-resolution-after-churn | 3000 | 0.852 / 0.876 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| load-short-lines | singapore | 8416 | 262144 | 262144 |
| load-short-lines | vscode | 7096 | 160004 | 160004 |
| load-long-line | singapore | 4168 | 0 | 0 |
| load-long-line | vscode | 7792 | 0 | 0 |
| sequential-typing | singapore | 51880 | 65536 | 65536 |
| sequential-typing | vscode | 89176 | 40004 | 40004 |
| typing-with-lookups | singapore | 53336 | 66560 | 66560 |
| typing-with-lookups | vscode | 89592 | 40004 | 40004 |
| random-insertions | singapore | -425416 | 65536 | 65536 |
| random-insertions | vscode | 617032 | 40004 | 40004 |
| random-replacements | singapore | -838816 | 66560 | 66560 |
| random-replacements | vscode | 642992 | 40004 | 40004 |
| eight-cursor-batches | singapore | -442416 | 66560 | 66560 |
| eight-cursor-batches | vscode | 587776 | 40004 | 40004 |
| mixed-edit-churn | singapore | -323832 | 66048 | 66048 |
| mixed-edit-churn | vscode | 543576 | 40004 | 40004 |
| large-paste-delete | singapore | 627080 | 65536 | 65536 |
| large-paste-delete | vscode | 55984 | 972164 | 972164 |
| lines-sequential-after-churn | singapore | 1361728 | 66048 | 66048 |
| lines-sequential-after-churn | vscode | 504080 | 40004 | 40004 |
| lines-random-after-churn | singapore | 1361792 | 66048 | 66048 |
| lines-random-after-churn | vscode | 512528 | 40004 | 40004 |
| ranges-after-churn | singapore | 1361536 | 66048 | 66048 |
| ranges-after-churn | vscode | 539752 | 40004 | 40004 |
| offset-to-position | singapore | 1362104 | 66048 | 66048 |
| offset-to-position | vscode | 534400 | 40004 | 40004 |
| position-to-offset | singapore | 1362016 | 66048 | 66048 |
| position-to-offset | vscode | 524232 | 40004 | 40004 |
| full-read-after-churn | singapore | 1354864 | 66048 | 66048 |
| full-read-after-churn | vscode | 516592 | 40004 | 40004 |
| persistent-history | singapore | 3933968 | 66048 | 66048 |
| branch-edits | singapore | -340296 | 66048 | 66048 |
| anchor-resolution-after-churn | singapore | 1389144 | 66048 | 66048 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

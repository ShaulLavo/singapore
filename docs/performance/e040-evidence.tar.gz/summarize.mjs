import { readdirSync, readFileSync } from 'node:fs'
const dir = process.argv[2] ?? '/work/tmp/e040-timing'
const configs = (process.argv[3] ?? 'treap,avl-split,avl-direct,wb29-split,wb29-direct,wb25-direct,wb20-direct').split(',')
const median = (v) => v.toSorted((a, b) => a - b)[v.length >> 1]
const table = new Map()
const control = new Map()
for (const file of readdirSync(dir)) {
  const match = /^(.*)-(\d+)\.json$/.exec(file)
  if (!match || !configs.includes(match[1])) continue
  for (const w of JSON.parse(readFileSync(`${dir}/${file}`)).workloads) {
    const row = table.get(w.name) ?? new Map()
    table.set(w.name, row)
    row.set(match[1], [...(row.get(match[1]) ?? []), w.engines.singapore.timeMs.median])
    if (w.engines.vscode) control.set(w.name, [...(control.get(w.name) ?? []), w.engines.vscode.timeMs.median])
  }
}
console.log(`| Lane | Control | ${configs.join(' | ')} |`)
console.log(`| --- | ---: | ${configs.map(() => '---:').join(' | ')} |`)
for (const [lane, row] of table) {
  const c = control.has(lane) ? median(control.get(lane)) : null
  const cells = configs.map((k) => {
    const v = row.get(k)
    if (!v) return '—'
    const m = median(v)
    return c ? `${m.toFixed(2)} (${(m / c).toFixed(2)}x)` : m.toFixed(2)
  })
  console.log(`| ${lane} | ${c ? c.toFixed(2) : '—'} | ${cells.join(' | ')} |`)
}

# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## random-insertions

1500 logical operations per replay.

### singapore

CPU: 308 in-workload samples; 42 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 144 | 46.8% |
| reverse index | 86 | 27.9% |
| buffer store / line index | 64 | 20.8% |
| adapter / harness / other | 8 | 2.6% |
| edit preparation / boundary policy | 6 | 1.9% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:117:insertIntoPieceTable`: 97.4% of in-workload samples.
- `textbuffer/dist/edits.js:130:insertTextAt`: 96.4% of in-workload samples.
- `textbuffer/dist/tree.js:170:insertAtVisibleOffset`: 67.5% of in-workload samples.
- `textbuffer/dist/tree.js:208:insertAtLanding`: 35.7% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:66:applyReverseIndexChanges`: 27.9% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:44:insertReverseIndexNode`: 26.9% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 375 | 0.25 |
| buffers.growTailLineIndex.indexInputCodeUnits | 2249 | 1.50 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| join.join.calls | 18438 | 12.29 |
| join.rotateLeft.calls | 322 | 0.21 |
| join.rotateRight.calls | 322 | 0.21 |
| node.cloneNode.calls | 15449 | 10.30 |
| node.createNode.calls | 2995 | 2.00 |
| node.own.calls | 18263 | 12.18 |
| priority.priorityForReverseKey.calls | 2995 | 2.00 |
| reverseIndex.cloneReverseIndexNode.calls | 29976 | 19.98 |
| reverseIndex.createReverseIndexNode.calls | 2995 | 2.00 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1495 | 1.00 |
| reverseIndex.ownReverseIndexNode.calls | 59658 | 39.77 |

### vscode

CPU: 153 in-workload samples; 32 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 95 | 62.1% |
| red-black tree | 55 | 35.9% |
| adapter / harness / other | 3 | 2.0% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 98.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 30.7% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 29.4% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 27.5% of in-workload samples.
- `vscode/dist/rbTreeBase.js:355:recomputeTreeMetadata`: 17.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 13.7% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 2250 | 1.50 |
| pieceTreeBase.createLineStartsFast.loopIterations | 2250 | 1.50 |
| rbTreeBase.leftRotate.calls | 1800 | 1.20 |
| rbTreeBase.rightRotate.calls | 1800 | 1.20 |
| rbTreeBase.TreeNode.constructor.calls | 2995 | 2.00 |

## random-replacements

1500 logical operations per replay.

### vscode

CPU: 179 in-workload samples; 34 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 115 | 64.2% |
| red-black tree | 53 | 29.6% |
| adapter / harness / other | 11 | 6.1% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 50.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 43.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 33.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 25.7% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 24.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:936:shrinkNode`: 20.1% of in-workload samples.

Structure after workload: {"pieces":2917,"invisible":0,"visible":2917,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 3380 | 2.25 |
| pieceTreeBase.createLineStartsFast.loopIterations | 3380 | 2.25 |
| rbTreeBase.leftRotate.calls | 1726 | 1.15 |
| rbTreeBase.rightRotate.calls | 1755 | 1.17 |
| rbTreeBase.TreeNode.constructor.calls | 2950 | 1.97 |

### singapore

CPU: 540 in-workload samples; 39 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 262 | 48.5% |
| reverse index | 131 | 24.3% |
| buffer store / line index | 76 | 14.1% |
| adapter / harness / other | 56 | 10.4% |
| edit preparation / boundary policy | 15 | 2.8% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:146:deleteFromPieceTable`: 64.6% of in-workload samples.
- `textbuffer/dist/edits.js:152:deleteRange`: 55.7% of in-workload samples.
- `textbuffer/dist/tree.js:284:hideVisibleRange`: 34.3% of in-workload samples.
- `textbuffer/dist/edits.js:117:insertIntoPieceTable`: 33.1% of in-workload samples.
- `textbuffer/dist/edits.js:130:insertTextAt`: 32.8% of in-workload samples.
- `textbuffer/dist/tree.js:170:insertAtVisibleOffset`: 28.0% of in-workload samples.

Structure after workload: {"pieces":4437,"invisible":1520,"visible":2917,"maxDepth":15,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 187 | 0.12 |
| buffers.extendBufferLineIndex.indexInputCodeUnits | 1860 | 1.24 |
| buffers.extendBufferLineIndex.loopIterations | 103 | 0.07 |
| buffers.growTailLineIndex.indexInputCodeUnits | 3376 | 2.25 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| buffers.pushLineBreakOffset.typedArrayCapacityBytes | 1792 | 1.19 |
| buffers.pushLineBreakOffset.typedArrayCopiedBytes | 768 | 0.51 |
| edits.snapEditRange.calls | 1453 | 0.97 |
| join.join.calls | 35113 | 23.41 |
| join.rotateLeft.calls | 482 | 0.32 |
| join.rotateRight.calls | 539 | 0.36 |
| node.cloneNode.calls | 31437 | 20.96 |
| node.createNode.calls | 4436 | 2.96 |
| node.own.calls | 36053 | 24.04 |
| priority.priorityForReverseKey.calls | 4436 | 2.96 |
| reads.splitsSurrogatePair.calls | 2906 | 1.94 |
| reverseIndex.cloneReverseIndexNode.calls | 31971 | 21.31 |
| reverseIndex.createReverseIndexNode.calls | 4436 | 2.96 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1566 | 1.04 |
| reverseIndex.ownReverseIndexNode.calls | 88434 | 58.96 |

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

import { packEditorTokens, splicePackedEditorTokens, unpackEditorTokens } from '/work/projects/Editor/packages/editor/src/syntax/packedTokens'
import { projectTokensThroughEdit } from '/work/projects/Editor/packages/editor/src/editor/tokenProjection'

const styles = Array.from({ length: 12 }, (_, i) => ({ color: `#${(i * 1234567).toString(16).padStart(6, '0').slice(0, 6)}` }))
function build(lines: number) {
  const tokens = []
  let offset = 0
  for (let line = 0; line < lines; line += 1) {
    for (let t = 0; t < 5; t += 1) {
      tokens.push({ start: offset, end: offset + 6, style: styles[(line + t) % 12]! })
      offset += 8
    }
    offset += 1
  }
  return { tokens, length: offset }
}
function median(xs: number[]) { xs.sort((a, b) => a - b); return xs[xs.length >> 1]! }
function time(label: string, fn: () => unknown, runs = 15) {
  for (let i = 0; i < 3; i += 1) fn()
  const samples: number[] = []
  for (let i = 0; i < runs; i += 1) { const s = performance.now(); fn(); samples.push(performance.now() - s) }
  console.log(label.padEnd(44), median(samples).toFixed(3), 'ms')
}
for (const lines of [100_000, 500_000]) {
  const { tokens, length } = build(lines)
  const packed = packEditorTokens(tokens)
  const unpacked = unpackEditorTokens(packed)
  const text = 'x'.repeat(length)
  const at = Math.floor(length / 2)
  console.log(`--- ${lines} lines, ${tokens.length} tokens`)
  time('unpackEditorTokens', () => unpackEditorTokens(packed))
  const patchTokens = packEditorTokens(tokens.slice(0, 5).map((t) => ({ ...t, start: t.start + at, end: t.end + at })))
  time('splicePackedEditorTokens (copy)', () => splicePackedEditorTokens(packed, { fromOffset: at, oldEndOffset: at + 41, newEndOffset: at + 42, tokensPacked: patchTokens }))
  time('projectTokensThroughEdit (lazy objects)', () => projectTokensThroughEdit(unpacked, { from: at, to: at, text: 'a' }, text))
  time('editorTokensEqual-like every()', () => unpacked.every((t, i) => t.style === unpacked[i]!.style && t.start === unpacked[i]!.start))
}

// Baseline (Editor main, object tokens): what one keystroke costs the token path end to end.
const root = process.argv[2]!
const { packEditorTokens, splicePackedEditorTokens, unpackEditorTokens } = await import(`${root}/packages/editor/src/syntax/packedTokens`)
const { projectTokensThroughEdit } = await import(`${root}/packages/editor/src/editor/tokenProjection`)
const { editorTokensEqual } = await import(`${root}/packages/editor/src/virtualization/virtualizedTextViewHelpers`)

const styles = Array.from({ length: 12 }, (_, i) => ({ color: `#${(0x111111 * (i + 1)).toString(16).slice(0, 6)}` }))
const LINE = 41
function build(lines: number) {
  const tokens = []
  for (let line = 0; line < lines; line += 1) {
    for (let t = 0; t < 5; t += 1) tokens.push({ start: line * LINE + t * 8, end: line * LINE + t * 8 + 6, style: styles[(line + t) % 12]! })
  }
  return tokens
}
function linePatch(line: number, grow: number) {
  const tokens = []
  for (let t = 0; t < 5; t += 1) tokens.push({ start: line * LINE + t * 8 + (t > 0 ? grow : 0), end: line * LINE + t * 8 + 6 + grow, style: styles[(line + t) % 12]! })
  return packEditorTokens(tokens)
}
function changedTokenRange(previous: any[], next: any[]) {
  const same = (a: any, b: any) => a.start === b.start && a.end === b.end && a.style.color === b.style.color
  let start = 0
  while (start < previous.length && start < next.length && same(previous[start], next[start])) start += 1
  let pe = previous.length, ne = next.length
  while (pe > start && ne > start && same(previous[pe - 1], next[ne - 1])) { pe -= 1; ne -= 1 }
  return { start, deleteCount: pe - start, insertEnd: ne }
}
const median = (xs: number[]) => xs.sort((a, b) => a - b)[xs.length >> 1]!
const results: Record<string, unknown>[] = []
for (const lines of [100_000, 500_000]) {
  const packed0 = packEditorTokens(build(lines))
  const line = lines >> 1
  const at = line * LINE + 3
  const stages = { project: [] as number[], splice: [] as number[], unpack: [] as number[], adoptCompare: [] as number[], minimapDiff: [] as number[], total: [] as number[] }
  for (let run = 0; run < 12; run += 1) {
    let packed = packed0
    let view = unpackEditorTokens(packed)
    const t0 = performance.now()
    const projected = projectTokensThroughEdit(view, { from: at, to: at, text: 'x' }, '')
    const t1 = performance.now()
    packed = splicePackedEditorTokens(packed, { fromOffset: line * LINE, oldEndOffset: (line + 1) * LINE, newEndOffset: (line + 1) * LINE + 1, tokensPacked: linePatch(line, 1) })
    const t2 = performance.now()
    const answered = unpackEditorTokens(packed)
    const t3 = performance.now()
    editorTokensEqual(projected, answered)
    const t4 = performance.now()
    changedTokenRange(projected as any[], answered)
    const t5 = performance.now()
    view = answered
    if (run < 4) continue
    stages.project.push(t1 - t0); stages.splice.push(t2 - t1); stages.unpack.push(t3 - t2); stages.adoptCompare.push(t4 - t3); stages.minimapDiff.push(t5 - t4); stages.total.push(t5 - t0)
  }
  const row: Record<string, unknown> = { lines, tokens: lines * 5 }
  for (const [name, samples] of Object.entries(stages)) row[name] = Number(median(samples).toFixed(3))
  results.push(row)
}
console.table(results)

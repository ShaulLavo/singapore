# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 19670e402d077b8f883c6c09a5298ee56f5cc63b.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.568 / 0.589 | 0.602 / 0.634 | 0.94x |
| typing-with-lookups | 3000 | 0.781 / 0.796 | 0.934 / 1.019 | 0.84x |
| random-insertions | 1500 | 3.509 / 3.595 | 1.074 / 1.221 | 3.27x |
| random-replacements | 1500 | 7.251 / 10.996 | 1.360 / 1.437 | 5.33x |
| eight-cursor-batches | 187 | 4.129 / 4.313 | 1.192 / 1.349 | 3.46x |
| mixed-edit-churn | 1500 | 6.248 / 6.420 | 1.236 / 1.351 | 5.06x |
| persistent-history | 1500 | 6.287 / 6.460 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 62240 | 65536 | 65536 |
| sequential-typing | vscode | 89224 | 40004 | 40004 |
| typing-with-lookups | singapore | 75992 | 66560 | 66560 |
| typing-with-lookups | vscode | 80384 | 40004 | 40004 |
| random-insertions | singapore | -433992 | 65536 | 65536 |
| random-insertions | vscode | 616944 | 40004 | 40004 |
| random-replacements | singapore | -829536 | 66560 | 66560 |
| random-replacements | vscode | 638944 | 40004 | 40004 |
| eight-cursor-batches | singapore | -440488 | 66560 | 66560 |
| eight-cursor-batches | vscode | 574904 | 40004 | 40004 |
| mixed-edit-churn | singapore | -341840 | 66560 | 66560 |
| mixed-edit-churn | vscode | 541472 | 40004 | 40004 |
| persistent-history | singapore | 4120056 | 66560 | 66560 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

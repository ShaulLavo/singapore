# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 19670e402d077b8f883c6c09a5298ee56f5cc63b.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.505 / 0.511 | 0.606 / 0.626 | 0.83x |
| typing-with-lookups | 3000 | 0.737 / 0.780 | 0.923 / 1.040 | 0.80x |
| random-insertions | 1500 | 3.036 / 3.137 | 1.102 / 1.139 | 2.75x |
| random-replacements | 1500 | 6.108 / 6.306 | 1.359 / 1.453 | 4.50x |
| eight-cursor-batches | 187 | 3.407 / 3.531 | 1.142 / 1.249 | 2.98x |
| mixed-edit-churn | 1500 | 5.100 / 5.190 | 1.146 / 1.204 | 4.45x |
| persistent-history | 1500 | 5.074 / 5.098 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 68832 | 65536 | 65536 |
| sequential-typing | vscode | 89176 | 40004 | 40004 |
| typing-with-lookups | singapore | 77424 | 66560 | 66560 |
| typing-with-lookups | vscode | 89592 | 40004 | 40004 |
| random-insertions | singapore | -433616 | 65536 | 65536 |
| random-insertions | vscode | 617032 | 40004 | 40004 |
| random-replacements | singapore | -834416 | 66560 | 66560 |
| random-replacements | vscode | 643664 | 40004 | 40004 |
| eight-cursor-batches | singapore | -444328 | 66560 | 66560 |
| eight-cursor-batches | vscode | 587776 | 40004 | 40004 |
| mixed-edit-churn | singapore | -349704 | 66048 | 66048 |
| mixed-edit-churn | vscode | 543576 | 40004 | 40004 |
| persistent-history | singapore | 4043984 | 66048 | 66048 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

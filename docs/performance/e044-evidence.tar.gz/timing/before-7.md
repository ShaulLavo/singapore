# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 19670e402d077b8f883c6c09a5298ee56f5cc63b.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.701 / 0.712 | 0.610 / 0.623 | 1.15x |
| typing-with-lookups | 3000 | 0.948 / 0.985 | 0.924 / 0.993 | 1.03x |
| random-insertions | 1500 | 3.553 / 3.718 | 1.082 / 1.206 | 3.28x |
| random-replacements | 1500 | 7.352 / 7.432 | 1.376 / 1.520 | 5.34x |
| eight-cursor-batches | 187 | 3.851 / 4.042 | 1.161 / 1.180 | 3.32x |
| mixed-edit-churn | 1500 | 6.140 / 6.765 | 1.182 / 1.414 | 5.19x |
| persistent-history | 1500 | 6.207 / 6.256 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 77696 | 65536 | 65536 |
| sequential-typing | vscode | 89176 | 40004 | 40004 |
| typing-with-lookups | singapore | 63512 | 66560 | 66560 |
| typing-with-lookups | vscode | 89592 | 40004 | 40004 |
| random-insertions | singapore | -432448 | 65536 | 65536 |
| random-insertions | vscode | 617032 | 40004 | 40004 |
| random-replacements | singapore | -830160 | 66560 | 66560 |
| random-replacements | vscode | 643664 | 40004 | 40004 |
| eight-cursor-batches | singapore | -442464 | 66560 | 66560 |
| eight-cursor-batches | vscode | 587776 | 40004 | 40004 |
| mixed-edit-churn | singapore | -346064 | 66048 | 66048 |
| mixed-edit-churn | vscode | 551776 | 40004 | 40004 |
| persistent-history | singapore | 4138368 | 66048 | 66048 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

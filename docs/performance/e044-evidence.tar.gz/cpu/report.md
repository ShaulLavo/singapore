# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## sequential-typing

1500 logical operations per replay.

### singapore

CPU: 38 in-workload samples; 39 excluded. Fewer than 100 in-workload samples: increase --repeats; do not rank small shares.

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| edit preparation / boundary policy | 12 | 31.6% |
| buffer store / line index | 11 | 28.9% |
| piece tree | 10 | 26.3% |
| adapter / harness / other | 3 | 7.9% |
| reverse index | 2 | 5.3% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:131:insertTextAt`: 92.1% of in-workload samples.
- `textbuffer/dist/edits.js:118:insertIntoPieceTable`: 92.1% of in-workload samples.
- `textbuffer/dist/tree.js:207:splitByVisibleOffset`: 39.5% of in-workload samples.
- `textbuffer/dist/tree.js:178:probeAtEnd`: 31.6% of in-workload samples.
- `textbuffer/dist/tree.js:101:coalescedPiece`: 21.1% of in-workload samples.
- `textbuffer/dist/buffers.js:325:extendTailChunk`: 15.8% of in-workload samples.

Structure after workload: {"pieces":3,"invisible":0,"visible":3,"maxDepth":2,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 187 | 0.12 |
| buffers.extendTailChunk.calls | 1499 | 1.00 |
| buffers.growTailLineIndex.indexInputCodeUnits | 3370 | 2.25 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| priority.priorityForPiece.calls | 3 | 0.00 |
| reverseIndex.cloneReverseIndexNode.calls | 1500 | 1.00 |
| reverseIndex.createReverseIndexNode.calls | 2 | 0.00 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1500 | 1.00 |
| reverseIndex.ownReverseIndexNode.calls | 1506 | 1.00 |
| tree.cloneNode.calls | 1499 | 1.00 |
| tree.createNode.calls | 3 | 0.00 |
| tree.own.calls | 1501 | 1.00 |

### vscode

CPU: 37 in-workload samples; 38 excluded. Fewer than 100 in-workload samples: increase --repeats; do not rank small shares.

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 30 | 81.1% |
| adapter / harness / other | 6 | 16.2% |
| red-black tree | 1 | 2.7% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 83.8% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:953:appendToNode`: 56.8% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:661:positionInBuffer`: 13.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:41:createLineStartsFast`: 8.1% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:179:get`: 5.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 5.4% of in-workload samples.

Structure after workload: {"pieces":3,"invisible":0,"visible":3,"maxDepth":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 3371 | 2.25 |
| pieceTreeBase.createLineStartsFast.loopIterations | 3371 | 2.25 |
| rbTreeBase.leftRotate.calls | 1 | 0.00 |
| rbTreeBase.rightRotate.calls | 1 | 0.00 |
| rbTreeBase.TreeNode.constructor.calls | 2 | 0.00 |

## random-insertions

1500 logical operations per replay.

### vscode

CPU: 155 in-workload samples; 29 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 97 | 62.6% |
| red-black tree | 51 | 32.9% |
| adapter / harness / other | 7 | 4.5% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 95.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 25.8% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 24.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 23.9% of in-workload samples.
- `vscode/dist/rbTreeBase.js:355:recomputeTreeMetadata`: 16.8% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 14.8% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 2250 | 1.50 |
| pieceTreeBase.createLineStartsFast.loopIterations | 2250 | 1.50 |
| rbTreeBase.leftRotate.calls | 1800 | 1.20 |
| rbTreeBase.rightRotate.calls | 1800 | 1.20 |
| rbTreeBase.TreeNode.constructor.calls | 2995 | 2.00 |

### singapore

CPU: 381 in-workload samples; 42 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 183 | 48.0% |
| reverse index | 90 | 23.6% |
| buffer store / line index | 71 | 18.6% |
| edit preparation / boundary policy | 31 | 8.1% |
| adapter / harness / other | 6 | 1.6% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:118:insertIntoPieceTable`: 98.4% of in-workload samples.
- `textbuffer/dist/edits.js:131:insertTextAt`: 97.9% of in-workload samples.
- `textbuffer/dist/edits.js:162:finishInsert`: 48.8% of in-workload samples.
- `textbuffer/dist/tree.js:207:splitByVisibleOffset`: 48.0% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:65:applyReverseIndexChanges`: 23.6% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:43:insertReverseIndexNode`: 22.8% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":28,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 375 | 0.25 |
| buffers.growTailLineIndex.indexInputCodeUnits | 2249 | 1.50 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| priority.priorityForPiece.calls | 4490 | 2.99 |
| reverseIndex.cloneReverseIndexNode.calls | 29976 | 19.98 |
| reverseIndex.createReverseIndexNode.calls | 2995 | 2.00 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1495 | 1.00 |
| reverseIndex.ownReverseIndexNode.calls | 59658 | 39.77 |
| tree.cloneNode.calls | 16926 | 11.28 |
| tree.createNode.calls | 4490 | 2.99 |
| tree.own.calls | 45165 | 30.11 |

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

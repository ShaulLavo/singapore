# Textbuffer comparison

Profile: standard, retention history. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 5469b377031b56ceae57bd62051976377bc68eb7.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.654 / 0.694 | 0.621 / 0.702 | 1.05x |
| typing-with-lookups | 3000 | 0.898 / 0.953 | 0.942 / 0.965 | 0.95x |
| random-insertions | 1500 | 4.904 / 7.567 | 1.096 / 1.135 | 4.48x |
| random-replacements | 1500 | 8.446 / 8.738 | 1.371 / 1.438 | 6.16x |
| eight-cursor-batches | 187 | 5.034 / 5.274 | 1.161 / 1.199 | 4.34x |
| mixed-edit-churn | 1500 | 7.092 / 7.413 | 1.165 / 1.318 | 6.09x |
| persistent-history | 1500 | 7.691 / 8.634 | not equivalent | separate lane |
| branch-edits | 64 | 0.439 / 0.514 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 64920 | 65536 | 65536 |
| sequential-typing | vscode | 89176 | 40004 | 40004 |
| typing-with-lookups | singapore | 46944 | 66560 | 66560 |
| typing-with-lookups | vscode | 87776 | 40004 | 40004 |
| random-insertions | singapore | -427104 | 65536 | 65536 |
| random-insertions | vscode | 617640 | 40004 | 40004 |
| random-replacements | singapore | -819816 | 66560 | 66560 |
| random-replacements | vscode | 645128 | 40004 | 40004 |
| eight-cursor-batches | singapore | -442520 | 66560 | 66560 |
| eight-cursor-batches | vscode | 587856 | 40004 | 40004 |
| mixed-edit-churn | singapore | -335480 | 66048 | 66048 |
| mixed-edit-churn | vscode | 552384 | 40004 | 40004 |
| persistent-history | singapore | 4144128 | 66048 | 66048 |
| branch-edits | singapore | -335008 | 66048 | 66048 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

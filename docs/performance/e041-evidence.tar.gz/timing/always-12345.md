# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 5469b377031b56ceae57bd62051976377bc68eb7.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.527 / 0.554 | 0.604 / 0.624 | 0.87x |
| typing-with-lookups | 3000 | 0.745 / 0.755 | 0.979 / 1.236 | 0.76x |
| random-insertions | 1500 | 4.972 / 5.053 | 1.068 / 1.087 | 4.65x |
| random-replacements | 1500 | 8.741 / 9.013 | 1.363 / 1.398 | 6.41x |
| eight-cursor-batches | 187 | 5.285 / 5.337 | 1.182 / 1.309 | 4.47x |
| mixed-edit-churn | 1500 | 8.148 / 8.322 | 1.268 / 1.320 | 6.43x |
| persistent-history | 1500 | 7.916 / 8.174 | not equivalent | separate lane |
| branch-edits | 64 | 0.445 / 0.465 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 64744 | 65536 | 65536 |
| sequential-typing | vscode | 89224 | 40004 | 40004 |
| typing-with-lookups | singapore | 42768 | 66560 | 66560 |
| typing-with-lookups | vscode | 89840 | 40004 | 40004 |
| random-insertions | singapore | -435032 | 65536 | 65536 |
| random-insertions | vscode | 611024 | 40004 | 40004 |
| random-replacements | singapore | -820048 | 66560 | 66560 |
| random-replacements | vscode | 648888 | 40004 | 40004 |
| eight-cursor-batches | singapore | -440712 | 66560 | 66560 |
| eight-cursor-batches | vscode | 571176 | 40004 | 40004 |
| mixed-edit-churn | singapore | -350960 | 66560 | 66560 |
| mixed-edit-churn | vscode | 541472 | 40004 | 40004 |
| persistent-history | singapore | 4126200 | 66560 | 66560 |
| branch-edits | singapore | -351432 | 66560 | 66560 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

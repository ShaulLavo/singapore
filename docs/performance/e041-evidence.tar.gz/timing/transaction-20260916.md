# Textbuffer comparison

Profile: standard, retention transaction. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 5469b377031b56ceae57bd62051976377bc68eb7.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.696 / 0.714 | 0.644 / 0.693 | 1.08x |
| typing-with-lookups | 3000 | 0.928 / 0.964 | 0.985 / 1.051 | 0.94x |
| random-insertions | 1500 | 5.190 / 6.652 | 1.224 / 1.327 | 4.24x |
| random-replacements | 1500 | 8.891 / 10.399 | 1.367 / 1.570 | 6.50x |
| eight-cursor-batches | 187 | 5.258 / 5.382 | 1.163 / 1.349 | 4.52x |
| mixed-edit-churn | 1500 | 7.651 / 7.920 | 1.193 / 1.209 | 6.41x |
| persistent-history | 1500 | 7.597 / 7.733 | not equivalent | separate lane |
| branch-edits | 64 | 0.449 / 0.470 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 57680 | 65536 | 65536 |
| sequential-typing | vscode | 89152 | 40004 | 40004 |
| typing-with-lookups | singapore | 54296 | 66560 | 66560 |
| typing-with-lookups | vscode | 89472 | 40004 | 40004 |
| random-insertions | singapore | 1047784 | 65536 | 65536 |
| random-insertions | vscode | 621696 | 40004 | 40004 |
| random-replacements | singapore | -815128 | 66560 | 66560 |
| random-replacements | vscode | 618952 | 40004 | 40004 |
| eight-cursor-batches | singapore | -431656 | 66560 | 66560 |
| eight-cursor-batches | vscode | 576688 | 40004 | 40004 |
| mixed-edit-churn | singapore | 1359984 | 66560 | 66560 |
| mixed-edit-churn | vscode | 552024 | 40004 | 40004 |
| persistent-history | singapore | 4180632 | 66560 | 66560 |
| branch-edits | singapore | -342024 | 66560 | 66560 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

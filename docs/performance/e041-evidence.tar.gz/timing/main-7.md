# Textbuffer comparison

Profile: standard. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 5469b377031b56ceae57bd62051976377bc68eb7.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.644 / 0.647 | 0.627 / 0.653 | 1.03x |
| typing-with-lookups | 3000 | 0.892 / 0.903 | 0.938 / 1.000 | 0.95x |
| random-insertions | 1500 | 5.559 / 5.853 | 1.078 / 1.456 | 5.16x |
| random-replacements | 1500 | 11.233 / 11.570 | 1.363 / 1.424 | 8.24x |
| eight-cursor-batches | 187 | 5.478 / 5.744 | 1.158 / 1.270 | 4.73x |
| mixed-edit-churn | 1500 | 8.540 / 8.647 | 1.140 / 1.179 | 7.49x |
| persistent-history | 1500 | 9.347 / 9.551 | not equivalent | separate lane |
| branch-edits | 64 | 0.438 / 0.462 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 64312 | 65536 | 65536 |
| sequential-typing | vscode | 89264 | 40004 | 40004 |
| typing-with-lookups | singapore | 53560 | 66560 | 66560 |
| typing-with-lookups | vscode | 89592 | 40004 | 40004 |
| random-insertions | singapore | -481752 | 65536 | 65536 |
| random-insertions | vscode | 619168 | 40004 | 40004 |
| random-replacements | singapore | -902936 | 66560 | 66560 |
| random-replacements | vscode | 647864 | 40004 | 40004 |
| eight-cursor-batches | singapore | -491456 | 66560 | 66560 |
| eight-cursor-batches | vscode | 587856 | 40004 | 40004 |
| mixed-edit-churn | singapore | -408016 | 66048 | 66048 |
| mixed-edit-churn | vscode | 543576 | 40004 | 40004 |
| persistent-history | singapore | 3908688 | 66048 | 66048 |
| branch-edits | singapore | -410944 | 66048 | 66048 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

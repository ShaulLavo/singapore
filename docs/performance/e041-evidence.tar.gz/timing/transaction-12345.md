# Textbuffer comparison

Profile: standard, retention transaction. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 5469b377031b56ceae57bd62051976377bc68eb7.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.536 / 0.549 | 0.608 / 0.648 | 0.88x |
| typing-with-lookups | 3000 | 0.746 / 0.749 | 0.925 / 1.057 | 0.81x |
| random-insertions | 1500 | 5.314 / 5.529 | 1.117 / 1.148 | 4.76x |
| random-replacements | 1500 | 8.878 / 9.425 | 1.449 / 1.529 | 6.13x |
| eight-cursor-batches | 187 | 5.229 / 5.666 | 1.210 / 1.262 | 4.32x |
| mixed-edit-churn | 1500 | 7.806 / 7.931 | 1.272 / 1.323 | 6.14x |
| persistent-history | 1500 | 7.827 / 7.846 | not equivalent | separate lane |
| branch-edits | 64 | 0.477 / 0.884 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 64744 | 65536 | 65536 |
| sequential-typing | vscode | 89224 | 40004 | 40004 |
| typing-with-lookups | singapore | 41952 | 66560 | 66560 |
| typing-with-lookups | vscode | 89768 | 40004 | 40004 |
| random-insertions | singapore | -428200 | 65536 | 65536 |
| random-insertions | vscode | 616944 | 40004 | 40004 |
| random-replacements | singapore | -830112 | 66560 | 66560 |
| random-replacements | vscode | 647856 | 40004 | 40004 |
| eight-cursor-batches | singapore | -432160 | 66560 | 66560 |
| eight-cursor-batches | vscode | 571176 | 40004 | 40004 |
| mixed-edit-churn | singapore | -351096 | 66560 | 66560 |
| mixed-edit-churn | vscode | 535928 | 40004 | 40004 |
| persistent-history | singapore | 4126128 | 66560 | 66560 |
| branch-edits | singapore | -342760 | 66560 | 66560 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

# Textbuffer comparison

Profile: standard, retention transaction. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 5469b377031b56ceae57bd62051976377bc68eb7.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.668 / 0.677 | 0.608 / 0.654 | 1.10x |
| typing-with-lookups | 3000 | 0.916 / 0.982 | 0.931 / 1.020 | 0.98x |
| random-insertions | 1500 | 5.090 / 5.162 | 1.089 / 1.182 | 4.67x |
| random-replacements | 1500 | 8.455 / 8.582 | 1.375 / 1.468 | 6.15x |
| eight-cursor-batches | 187 | 5.064 / 5.139 | 1.142 / 1.175 | 4.43x |
| mixed-edit-churn | 1500 | 7.627 / 7.835 | 1.143 / 1.327 | 6.67x |
| persistent-history | 1500 | 7.659 / 7.741 | not equivalent | separate lane |
| branch-edits | 64 | 0.441 / 0.479 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 57976 | 65536 | 65536 |
| sequential-typing | vscode | 89248 | 40004 | 40004 |
| typing-with-lookups | singapore | 46816 | 66560 | 66560 |
| typing-with-lookups | vscode | 89592 | 40004 | 40004 |
| random-insertions | singapore | -432936 | 65536 | 65536 |
| random-insertions | vscode | 624792 | 40004 | 40004 |
| random-replacements | singapore | -832464 | 66560 | 66560 |
| random-replacements | vscode | 644000 | 40004 | 40004 |
| eight-cursor-batches | singapore | -434528 | 66560 | 66560 |
| eight-cursor-batches | vscode | 587568 | 40004 | 40004 |
| mixed-edit-churn | singapore | -345544 | 66048 | 66048 |
| mixed-edit-churn | vscode | 543576 | 40004 | 40004 |
| persistent-history | singapore | 4143672 | 66048 | 66048 |
| branch-edits | singapore | -341592 | 66048 | 66048 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

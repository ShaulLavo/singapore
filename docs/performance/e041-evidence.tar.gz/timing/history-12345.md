# Textbuffer comparison

Profile: standard, retention history. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 5469b377031b56ceae57bd62051976377bc68eb7.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.518 / 0.529 | 0.605 / 0.624 | 0.86x |
| typing-with-lookups | 3000 | 0.731 / 0.745 | 0.963 / 1.030 | 0.76x |
| random-insertions | 1500 | 4.684 / 4.745 | 1.077 / 1.132 | 4.35x |
| random-replacements | 1500 | 8.565 / 8.951 | 1.378 / 1.552 | 6.22x |
| eight-cursor-batches | 187 | 5.211 / 5.285 | 1.188 / 1.261 | 4.38x |
| mixed-edit-churn | 1500 | 7.225 / 7.465 | 1.251 / 1.291 | 5.78x |
| persistent-history | 1500 | 7.603 / 8.134 | not equivalent | separate lane |
| branch-edits | 64 | 0.439 / 0.465 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 64744 | 65536 | 65536 |
| sequential-typing | vscode | 89208 | 40004 | 40004 |
| typing-with-lookups | singapore | 42648 | 66560 | 66560 |
| typing-with-lookups | vscode | 89840 | 40004 | 40004 |
| random-insertions | singapore | -429120 | 65536 | 65536 |
| random-insertions | vscode | 615416 | 40004 | 40004 |
| random-replacements | singapore | -818280 | 66560 | 66560 |
| random-replacements | vscode | 657008 | 40004 | 40004 |
| eight-cursor-batches | singapore | -432512 | 66560 | 66560 |
| eight-cursor-batches | vscode | 571512 | 40004 | 40004 |
| mixed-edit-churn | singapore | -341072 | 66560 | 66560 |
| mixed-edit-churn | vscode | 539728 | 40004 | 40004 |
| persistent-history | singapore | 4126576 | 66560 | 66560 |
| branch-edits | singapore | -348448 | 66560 | 66560 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

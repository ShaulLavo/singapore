# Textbuffer comparison

Profile: standard, retention always. Node v26.7.0, V8 14.6.202.34-node.28.
Source commit: 5469b377031b56ceae57bd62051976377bc68eb7.
Microsoft standalone revision: fdca8848ba80c9421cce1894bc32851e1730bc88.

**Ratios are Singapore / vscode-textbuffer: below 1 is faster. No overall score.**
Times are milliseconds for the entire workload, not individual-operation p95 latency.

| Workload | Logical ops | Singapore median / p95 ms | VS Code median / p95 ms | Ratio |
| --- | ---: | ---: | ---: | ---: |
| sequential-typing | 1500 | 0.673 / 0.721 | 0.643 / 1.059 | 1.05x |
| typing-with-lookups | 3000 | 0.911 / 0.940 | 0.952 / 0.996 | 0.96x |
| random-insertions | 1500 | 5.046 / 5.090 | 1.084 / 1.196 | 4.65x |
| random-replacements | 1500 | 8.762 / 9.260 | 1.375 / 1.638 | 6.37x |
| eight-cursor-batches | 187 | 5.470 / 5.645 | 1.194 / 1.253 | 4.58x |
| mixed-edit-churn | 1500 | 7.991 / 8.305 | 1.161 / 1.226 | 6.88x |
| persistent-history | 1500 | 7.737 / 7.852 | not equivalent | separate lane |
| branch-edits | 64 | 0.429 / 0.452 | not equivalent | separate lane |

## Post-GC retained memory

Median deltas in bytes relative to the warmed process before creating the measured buffer.
Includes the active state, caches and retained versions. Not total allocations or peak memory.
`arrayBuffers` is included in `external`; do not add them together. Negative deltas indicate measurement noise.

| Workload | Engine | Heap | External | Array buffers |
| --- | --- | ---: | ---: | ---: |
| sequential-typing | singapore | 64688 | 65536 | 65536 |
| sequential-typing | vscode | 89176 | 40004 | 40004 |
| typing-with-lookups | singapore | 46816 | 66560 | 66560 |
| typing-with-lookups | vscode | 89592 | 40004 | 40004 |
| random-insertions | singapore | -432936 | 65536 | 65536 |
| random-insertions | vscode | 607424 | 40004 | 40004 |
| random-replacements | singapore | -813672 | 66560 | 66560 |
| random-replacements | vscode | 636880 | 40004 | 40004 |
| eight-cursor-batches | singapore | -436368 | 66560 | 66560 |
| eight-cursor-batches | vscode | 587856 | 40004 | 40004 |
| mixed-edit-churn | singapore | -338696 | 66048 | 66048 |
| mixed-edit-churn | vscode | 543744 | 40004 | 40004 |
| persistent-history | singapore | 4144176 | 66048 | 66048 |
| branch-edits | singapore | -341624 | 66048 | 66048 |

## Interpretation

- This is a Node text-buffer microbenchmark, not browser input-to-paint or a claim about current full VS Code.
- LF-normalized input, UTF-16 offsets, code-point-safe edit boundaries, no editor diagnostics.
- Range reads include two offset-to-position conversions on the VS Code adapter; Singapore line reads include line-boundary lookup. These are API-level costs, not equal primitive counts.
- Each sample is a fresh process. Warmups use fresh buffers. Pair order alternates. Fixture generation, setup edits, validation, forced GC and process startup are outside the timer.
- Normal GC during operations remains inside the measured time. Read-result sampling is included; exact read validation is outside it.
- Persistent history and anchor resolution are Singapore-only capabilities, with no fabricated VS Code equivalence.
- Raw samples, fixture hashes, source/build hashes, toolchain and machine metadata are in the adjacent JSON.
- Synthetic workload results on one machine require repetition across seeds, machines and browser engines.

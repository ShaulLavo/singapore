# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## random-insertions

1500 logical operations per replay.

### singapore

CPU: 685 in-workload samples; 38 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 364 | 53.1% |
| buffer store / line index | 102 | 14.9% |
| reverse index | 89 | 13.0% |
| edit preparation / boundary policy | 80 | 11.7% |
| adapter / harness / other | 50 | 7.3% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:118:insertIntoPieceTable`: 98.4% of in-workload samples.
- `textbuffer/dist/edits.js:127:insertTextAt`: 89.5% of in-workload samples.
- `textbuffer/dist/tree.js:73:splitByVisibleOffset`: 39.9% of in-workload samples.
- `textbuffer/dist/tree.js:59:merge`: 17.4% of in-workload samples.
- `textbuffer/dist/orders.js:3:allocateOrdersBetween`: 15.8% of in-workload samples.
- `textbuffer/dist/tree.js:48:updateNode`: 14.6% of in-workload samples.

### vscode

CPU: 152 in-workload samples; 33 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 92 | 60.5% |
| red-black tree | 53 | 34.9% |
| adapter / harness / other | 7 | 4.6% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 95.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 32.2% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 30.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 23.7% of in-workload samples.
- `vscode/dist/rbTreeBase.js:355:recomputeTreeMetadata`: 21.7% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 16.4% of in-workload samples.

## random-replacements

1500 logical operations per replay.

### vscode

CPU: 183 in-workload samples; 35 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 115 | 62.8% |
| red-black tree | 57 | 31.1% |
| adapter / harness / other | 11 | 6.0% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 50.8% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:563:delete`: 43.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 37.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 25.1% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 23.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 19.7% of in-workload samples.

### singapore

CPU: 1259 in-workload samples; 57 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 746 | 59.3% |
| reverse index | 205 | 16.3% |
| buffer store / line index | 115 | 9.1% |
| edit preparation / boundary policy | 110 | 8.7% |
| adapter / harness / other | 83 | 6.6% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:169:deleteFromPieceTable`: 63.4% of in-workload samples.
- `textbuffer/dist/edits.js:175:deleteRange`: 57.7% of in-workload samples.
- `textbuffer/dist/tree.js:73:splitByVisibleOffset`: 44.7% of in-workload samples.
- `textbuffer/dist/edits.js:118:insertIntoPieceTable`: 35.4% of in-workload samples.
- `textbuffer/dist/edits.js:127:insertTextAt`: 31.2% of in-workload samples.
- `textbuffer/dist/tree.js:48:updateNode`: 17.6% of in-workload samples.

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

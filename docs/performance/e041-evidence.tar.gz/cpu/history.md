# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention history; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## random-insertions

1500 logical operations per replay.

### singapore

CPU: 644 in-workload samples; 33 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 325 | 50.5% |
| edit preparation / boundary policy | 96 | 14.9% |
| buffer store / line index | 88 | 13.7% |
| reverse index | 79 | 12.3% |
| adapter / harness / other | 56 | 8.7% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:118:insertIntoPieceTable`: 98.4% of in-workload samples.
- `textbuffer/dist/edits.js:127:insertTextAt`: 88.0% of in-workload samples.
- `textbuffer/dist/tree.js:73:splitByVisibleOffset`: 35.7% of in-workload samples.
- `textbuffer/dist/orders.js:3:allocateOrdersBetween`: 16.8% of in-workload samples.
- `textbuffer/dist/tree.js:59:merge`: 14.6% of in-workload samples.
- `textbuffer/dist/tree.js:48:updateNode`: 12.4% of in-workload samples.

### vscode

CPU: 150 in-workload samples; 32 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 96 | 64.0% |
| red-black tree | 50 | 33.3% |
| adapter / harness / other | 4 | 2.7% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 97.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 30.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 29.3% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 26.7% of in-workload samples.
- `vscode/dist/rbTreeBase.js:355:recomputeTreeMetadata`: 19.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 15.3% of in-workload samples.

## random-replacements

1500 logical operations per replay.

### vscode

CPU: 184 in-workload samples; 32 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 134 | 72.8% |
| red-black tree | 46 | 25.0% |
| adapter / harness / other | 4 | 2.2% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 54.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 43.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 29.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 20.1% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 18.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:661:positionInBuffer`: 18.5% of in-workload samples.

### singapore

CPU: 1192 in-workload samples; 44 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 709 | 59.5% |
| reverse index | 156 | 13.1% |
| buffer store / line index | 125 | 10.5% |
| edit preparation / boundary policy | 118 | 9.9% |
| adapter / harness / other | 84 | 7.0% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:169:deleteFromPieceTable`: 63.3% of in-workload samples.
- `textbuffer/dist/edits.js:175:deleteRange`: 55.9% of in-workload samples.
- `textbuffer/dist/tree.js:73:splitByVisibleOffset`: 43.0% of in-workload samples.
- `textbuffer/dist/edits.js:118:insertIntoPieceTable`: 35.6% of in-workload samples.
- `textbuffer/dist/edits.js:127:insertTextAt`: 31.9% of in-workload samples.
- `textbuffer/dist/tree.js:59:merge`: 18.5% of in-workload samples.

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

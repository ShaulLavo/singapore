const root = process.argv[2]
const api = await import(root + '/packages/textbuffer/dist/index.js')
const fx = await import('/work/projects/Editor/packages/textbuffer/bench/fixtures.mjs')
const f = fx.makeFixtures('standard', 20260916).find((x) => x.name === 'sequential-typing')
const run = () => {
  let s = api.createPieceTableSnapshot(f.initial)
  const t = performance.now()
  for (const op of f.operations) s = api.insertIntoPieceTable(s, op.from, op.text)
  return performance.now() - t
}
for (let i = 0; i < 30; i++) run()
const times = []
for (let i = 0; i < 300; i++) times.push(run())
times.sort((a, b) => a - b)
console.log(root.split('/').at(-1), 'median', times[150].toFixed(4), 'p10', times[30].toFixed(4))

const root = process.argv[2]
const api = await import(root + '/packages/textbuffer/dist/index.js')
const fx = await import(root + '/packages/textbuffer/bench/fixtures.mjs')
const f = fx.makeFixtures('standard', 20260916).find((x) => x.name === 'mixed-edit-churn')
let s = api.createPieceTableSnapshot(f.initial)
const minGap = (node, acc = { prev: null, min: Infinity }) => {
  if (!node) return acc
  minGap(node.left, acc)
  if (acc.prev !== null) acc.min = Math.min(acc.min, node.piece.order - acc.prev)
  acc.prev = node.piece.order
  minGap(node.right, acc)
  return acc
}
let i = 0
for (const op of f.operations) {
  i++
  const e = op.edit ?? op
  if (e.to > e.from && e.text.length) s = api.applyBatchToPieceTable(s, [e])
  else if (e.to > e.from) s = api.deleteFromPieceTable(s, e.from, e.to - e.from)
  else if (e.text?.length) s = api.insertIntoPieceTable(s, e.from, e.text)
  if (i % 100 === 0) console.log(i, 'pieces', s.pieceCount, 'minGap', minGap(s.root).min)
}

# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## sequential-typing

1500 logical operations per replay.

### singapore

CPU: 110 in-workload samples; 185 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 40 | 36.4% |
| buffer store / line index | 36 | 32.7% |
| edit preparation / boundary policy | 16 | 14.5% |
| adapter / harness / other | 13 | 11.8% |
| reverse index | 5 | 4.5% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:130:insertTextAt`: 88.2% of in-workload samples.
- `textbuffer/dist/edits.js:117:insertIntoPieceTable`: 88.2% of in-workload samples.
- `textbuffer/dist/tree.js:170:insertAtVisibleOffset`: 56.4% of in-workload samples.
- `textbuffer/dist/tree.js:112:probeLanding`: 51.8% of in-workload samples.
- `textbuffer/dist/tree.js:81:probeAtEnd`: 49.1% of in-workload samples.
- `textbuffer/dist/tree.js:8:coalescedPiece`: 20.9% of in-workload samples.

### vscode

CPU: 113 in-workload samples; 172 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 95 | 84.1% |
| adapter / harness / other | 18 | 15.9% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 84.1% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:953:appendToNode`: 54.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:661:positionInBuffer`: 20.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:179:get`: 5.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 5.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:41:createLineStartsFast`: 2.7% of in-workload samples.

## mixed-edit-churn

1500 logical operations per replay.

### vscode

CPU: 560 in-workload samples; 148 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 353 | 63.0% |
| red-black tree | 178 | 31.8% |
| adapter / harness / other | 29 | 5.2% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 58.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 36.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 27.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:936:shrinkNode`: 26.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 23.4% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 23.0% of in-workload samples.

### singapore

CPU: 1859 in-workload samples; 158 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 800 | 43.0% |
| reverse index | 503 | 27.1% |
| buffer store / line index | 276 | 14.8% |
| adapter / harness / other | 244 | 13.1% |
| edit preparation / boundary policy | 36 | 1.9% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:161:applyBatchToPieceTable`: 69.4% of in-workload samples.
- `textbuffer/dist/edits.js:175:applyEdit`: 61.6% of in-workload samples.
- `textbuffer/dist/edits.js:152:deleteRange`: 60.7% of in-workload samples.
- `textbuffer/dist/tree.js:284:hideVisibleRange`: 36.7% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:66:applyReverseIndexChanges`: 27.1% of in-workload samples.
- `textbuffer/dist/edits.js:146:deleteFromPieceTable`: 26.1% of in-workload samples.

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

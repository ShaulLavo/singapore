# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## sequential-typing

1500 logical operations per replay.

### singapore

CPU: 34 in-workload samples; 38 excluded. Fewer than 100 in-workload samples: increase --repeats; do not rank small shares.

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| buffer store / line index | 14 | 41.2% |
| piece tree | 10 | 29.4% |
| edit preparation / boundary policy | 4 | 11.8% |
| adapter / harness / other | 3 | 8.8% |
| reverse index | 3 | 8.8% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:117:insertIntoPieceTable`: 91.2% of in-workload samples.
- `textbuffer/dist/edits.js:130:insertTextAt`: 88.2% of in-workload samples.
- `textbuffer/dist/tree.js:170:insertAtVisibleOffset`: 47.1% of in-workload samples.
- `textbuffer/dist/tree.js:81:probeAtEnd`: 41.2% of in-workload samples.
- `textbuffer/dist/tree.js:112:probeLanding`: 41.2% of in-workload samples.
- `textbuffer/dist/buffers.js:326:extendTailChunk`: 23.5% of in-workload samples.

Structure after workload: {"pieces":3,"invisible":0,"visible":3,"maxDepth":2,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 187 | 0.12 |
| buffers.extendTailChunk.calls | 1499 | 1.00 |
| buffers.growTailLineIndex.indexInputCodeUnits | 3370 | 2.25 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| join.join.calls | 3 | 0.00 |
| node.cloneNode.calls | 1500 | 1.00 |
| node.createNode.calls | 2 | 0.00 |
| node.own.calls | 1501 | 1.00 |
| priority.priorityForReverseKey.calls | 2 | 0.00 |
| reverseIndex.cloneReverseIndexNode.calls | 1500 | 1.00 |
| reverseIndex.createReverseIndexNode.calls | 2 | 0.00 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1500 | 1.00 |
| reverseIndex.ownReverseIndexNode.calls | 1506 | 1.00 |

### vscode

CPU: 38 in-workload samples; 37 excluded. Fewer than 100 in-workload samples: increase --repeats; do not rank small shares.

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 30 | 78.9% |
| adapter / harness / other | 6 | 15.8% |
| red-black tree | 2 | 5.3% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 84.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:953:appendToNode`: 52.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:661:positionInBuffer`: 15.8% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:179:get`: 7.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 7.9% of in-workload samples.
- `vscode/dist/rbTreeBase.js:345:updateTreeMetadata`: 5.3% of in-workload samples.

Structure after workload: {"pieces":3,"invisible":0,"visible":3,"maxDepth":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 3371 | 2.25 |
| pieceTreeBase.createLineStartsFast.loopIterations | 3371 | 2.25 |
| rbTreeBase.leftRotate.calls | 1 | 0.00 |
| rbTreeBase.rightRotate.calls | 1 | 0.00 |
| rbTreeBase.TreeNode.constructor.calls | 2 | 0.00 |

## random-insertions

1500 logical operations per replay.

### vscode

CPU: 154 in-workload samples; 28 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 96 | 62.3% |
| red-black tree | 53 | 34.4% |
| adapter / harness / other | 5 | 3.2% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 95.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 31.2% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 27.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 27.9% of in-workload samples.
- `vscode/dist/rbTreeBase.js:355:recomputeTreeMetadata`: 16.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 14.3% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 2250 | 1.50 |
| pieceTreeBase.createLineStartsFast.loopIterations | 2250 | 1.50 |
| rbTreeBase.leftRotate.calls | 1800 | 1.20 |
| rbTreeBase.rightRotate.calls | 1800 | 1.20 |
| rbTreeBase.TreeNode.constructor.calls | 2995 | 2.00 |

### singapore

CPU: 298 in-workload samples; 42 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 143 | 48.0% |
| reverse index | 83 | 27.9% |
| buffer store / line index | 61 | 20.5% |
| adapter / harness / other | 7 | 2.3% |
| edit preparation / boundary policy | 4 | 1.3% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:117:insertIntoPieceTable`: 97.7% of in-workload samples.
- `textbuffer/dist/edits.js:130:insertTextAt`: 97.3% of in-workload samples.
- `textbuffer/dist/tree.js:170:insertAtVisibleOffset`: 68.5% of in-workload samples.
- `textbuffer/dist/tree.js:208:insertAtLanding`: 32.6% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:66:applyReverseIndexChanges`: 27.9% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:44:insertReverseIndexNode`: 26.5% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 375 | 0.25 |
| buffers.growTailLineIndex.indexInputCodeUnits | 2249 | 1.50 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| join.join.calls | 18438 | 12.29 |
| join.rotateLeft.calls | 322 | 0.21 |
| join.rotateRight.calls | 322 | 0.21 |
| node.cloneNode.calls | 15449 | 10.30 |
| node.createNode.calls | 2995 | 2.00 |
| node.own.calls | 18263 | 12.18 |
| priority.priorityForReverseKey.calls | 2995 | 2.00 |
| reverseIndex.cloneReverseIndexNode.calls | 29976 | 19.98 |
| reverseIndex.createReverseIndexNode.calls | 2995 | 2.00 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1495 | 1.00 |
| reverseIndex.ownReverseIndexNode.calls | 59658 | 39.77 |

## random-replacements

1500 logical operations per replay.

### singapore

CPU: 543 in-workload samples; 41 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 249 | 45.9% |
| reverse index | 157 | 28.9% |
| buffer store / line index | 67 | 12.3% |
| adapter / harness / other | 63 | 11.6% |
| edit preparation / boundary policy | 7 | 1.3% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:161:applyBatchToPieceTable`: 95.6% of in-workload samples.
- `textbuffer/dist/edits.js:175:applyEdit`: 86.2% of in-workload samples.
- `textbuffer/dist/edits.js:152:deleteRange`: 52.9% of in-workload samples.
- `textbuffer/dist/edits.js:130:insertTextAt`: 34.8% of in-workload samples.
- `textbuffer/dist/tree.js:284:hideVisibleRange`: 29.5% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:66:applyReverseIndexChanges`: 28.7% of in-workload samples.

Structure after workload: {"pieces":4437,"invisible":1520,"visible":2917,"maxDepth":15,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 187 | 0.12 |
| buffers.extendBufferLineIndex.indexInputCodeUnits | 1860 | 1.24 |
| buffers.extendBufferLineIndex.loopIterations | 103 | 0.07 |
| buffers.growTailLineIndex.indexInputCodeUnits | 3376 | 2.25 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| buffers.pushLineBreakOffset.typedArrayCapacityBytes | 1792 | 1.19 |
| buffers.pushLineBreakOffset.typedArrayCopiedBytes | 768 | 0.51 |
| edits.snapEditRange.calls | 1453 | 0.97 |
| join.join.calls | 35113 | 23.41 |
| join.rotateLeft.calls | 482 | 0.32 |
| join.rotateRight.calls | 539 | 0.36 |
| node.cloneNode.calls | 31437 | 20.96 |
| node.createNode.calls | 4436 | 2.96 |
| node.own.calls | 36053 | 24.04 |
| priority.priorityForReverseKey.calls | 4436 | 2.96 |
| reads.splitsSurrogatePair.calls | 2906 | 1.94 |
| reverseIndex.cloneReverseIndexNode.calls | 31971 | 21.31 |
| reverseIndex.createReverseIndexNode.calls | 4436 | 2.96 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1566 | 1.04 |
| reverseIndex.ownReverseIndexNode.calls | 88434 | 58.96 |

### vscode

CPU: 182 in-workload samples; 34 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 122 | 67.0% |
| red-black tree | 53 | 29.1% |
| adapter / harness / other | 7 | 3.8% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 52.7% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:563:delete`: 42.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 37.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 23.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 21.4% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 20.3% of in-workload samples.

Structure after workload: {"pieces":2917,"invisible":0,"visible":2917,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 3380 | 2.25 |
| pieceTreeBase.createLineStartsFast.loopIterations | 3380 | 2.25 |
| rbTreeBase.leftRotate.calls | 1726 | 1.15 |
| rbTreeBase.rightRotate.calls | 1755 | 1.17 |
| rbTreeBase.TreeNode.constructor.calls | 2950 | 1.97 |

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

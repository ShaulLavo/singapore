#!/bin/bash
LANES=random-insertions,random-replacements,eight-cursor-batches,mixed-edit-churn,sequential-typing,typing-with-lookups,persistent-history,branch-edits,anchor-resolution-after-churn
OUT=/work/tmp/e045-timing/r2
for seed in 20260916 7 12345; do
  for warm in 2 8; do
    for which in before after; do
      if [ $which = before ]; then dir=/work/worktrees/Editor/e045-before; else dir=/work/projects/Editor; fi
      cd $dir/packages/textbuffer
      bun run bench -- --profile standard --seed $seed --warmups $warm --only $LANES --output $OUT/$which-w$warm-$seed.json 2>&1 | grep -E "rror"
    done
  done
done
echo DONE

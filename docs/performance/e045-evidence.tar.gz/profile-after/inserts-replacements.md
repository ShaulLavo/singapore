# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## random-insertions

1500 logical operations per replay.

### singapore

CPU: 310 in-workload samples; 41 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 148 | 47.7% |
| reverse index | 90 | 29.0% |
| buffer store / line index | 56 | 18.1% |
| adapter / harness / other | 12 | 3.9% |
| edit preparation / boundary policy | 4 | 1.3% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:173:insertIntoPieceTable`: 95.8% of in-workload samples.
- `textbuffer/dist/tree.js:170:insertAtVisibleOffset`: 65.8% of in-workload samples.
- `textbuffer/dist/edits.js:144:insertText`: 65.8% of in-workload samples.
- `textbuffer/dist/tree.js:208:insertAtLanding`: 31.9% of in-workload samples.
- `textbuffer/dist/edits.js:129:finishEdit`: 30.0% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:99:applyReverseIndexChanges`: 29.0% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 375 | 0.25 |
| buffers.growTailLineIndex.indexInputCodeUnits | 2249 | 1.50 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| join.join.calls | 18438 | 12.29 |
| join.rotateLeft.calls | 322 | 0.21 |
| join.rotateRight.calls | 322 | 0.21 |
| node.cloneNode.calls | 15449 | 10.30 |
| node.createNode.calls | 2995 | 2.00 |
| node.own.calls | 18263 | 12.18 |
| reverseIndex.cloneReverseIndexNode.calls | 29953 | 19.97 |
| reverseIndex.createReverseIndexNode.calls | 2995 | 2.00 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1495 | 1.00 |
| reverseIndex.ownReverseIndexNode.calls | 47911 | 31.94 |

### vscode

CPU: 153 in-workload samples; 30 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 92 | 60.1% |
| red-black tree | 58 | 37.9% |
| adapter / harness / other | 3 | 2.0% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 97.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 33.3% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 29.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 21.6% of in-workload samples.
- `vscode/dist/rbTreeBase.js:355:recomputeTreeMetadata`: 20.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 14.4% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 2250 | 1.50 |
| pieceTreeBase.createLineStartsFast.loopIterations | 2250 | 1.50 |
| rbTreeBase.leftRotate.calls | 1800 | 1.20 |
| rbTreeBase.rightRotate.calls | 1800 | 1.20 |
| rbTreeBase.TreeNode.constructor.calls | 2995 | 2.00 |

## random-replacements

1500 logical operations per replay.

### vscode

CPU: 182 in-workload samples; 37 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 131 | 72.0% |
| red-black tree | 45 | 24.7% |
| adapter / harness / other | 6 | 3.3% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 50.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 46.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 32.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 23.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:936:shrinkNode`: 22.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 21.4% of in-workload samples.

Structure after workload: {"pieces":2917,"invisible":0,"visible":2917,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 3380 | 2.25 |
| pieceTreeBase.createLineStartsFast.loopIterations | 3380 | 2.25 |
| rbTreeBase.leftRotate.calls | 1726 | 1.15 |
| rbTreeBase.rightRotate.calls | 1755 | 1.17 |
| rbTreeBase.TreeNode.constructor.calls | 2950 | 1.97 |

### singapore

CPU: 470 in-workload samples; 37 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 169 | 36.0% |
| reverse index | 129 | 27.4% |
| buffer store / line index | 85 | 18.1% |
| adapter / harness / other | 75 | 16.0% |
| edit preparation / boundary policy | 12 | 2.6% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:208:applyBatchToPieceTable`: 93.8% of in-workload samples.
- `textbuffer/dist/edits.js:160:replaceRange`: 51.3% of in-workload samples.
- `textbuffer/dist/tree.js:302:hideVisibleRange`: 50.6% of in-workload samples.
- `textbuffer/dist/tree.js:262:hidePieceRange`: 31.3% of in-workload samples.
- `textbuffer/dist/edits.js:129:finishEdit`: 27.7% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:99:applyReverseIndexChanges`: 27.4% of in-workload samples.

Structure after workload: {"pieces":4437,"invisible":1520,"visible":2917,"maxDepth":15,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 187 | 0.12 |
| buffers.growTailLineIndex.indexInputCodeUnits | 3376 | 2.25 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| edits.snapEditRange.calls | 1453 | 0.97 |
| join.join.calls | 18969 | 12.65 |
| join.rotateLeft.calls | 797 | 0.53 |
| join.rotateRight.calls | 1126 | 0.75 |
| node.cloneNode.calls | 15859 | 10.57 |
| node.createNode.calls | 4436 | 2.96 |
| node.own.calls | 24017 | 16.01 |
| reads.splitsSurrogatePair.calls | 2906 | 1.94 |
| reverseIndex.cloneReverseIndexNode.calls | 32350 | 21.57 |
| reverseIndex.createReverseIndexNode.calls | 4436 | 2.96 |
| reverseIndex.insertReverseIndexNode.replacementRecords | 1566 | 1.04 |
| reverseIndex.ownReverseIndexNode.calls | 70940 | 47.29 |

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

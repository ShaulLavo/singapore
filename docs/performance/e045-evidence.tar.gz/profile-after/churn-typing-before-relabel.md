# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## sequential-typing

1500 logical operations per replay.

### singapore

CPU: 106 in-workload samples; 180 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| buffer store / line index | 38 | 35.8% |
| piece tree | 28 | 26.4% |
| adapter / harness / other | 15 | 14.2% |
| edit preparation / boundary policy | 14 | 13.2% |
| reverse index | 11 | 10.4% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:173:insertIntoPieceTable`: 84.9% of in-workload samples.
- `textbuffer/dist/edits.js:144:insertText`: 68.9% of in-workload samples.
- `textbuffer/dist/tree.js:170:insertAtVisibleOffset`: 40.6% of in-workload samples.
- `textbuffer/dist/tree.js:81:probeAtEnd`: 36.8% of in-workload samples.
- `textbuffer/dist/tree.js:112:probeLanding`: 36.8% of in-workload samples.
- `textbuffer/dist/buffers.js:325:extendTailChunk`: 20.8% of in-workload samples.

### vscode

CPU: 117 in-workload samples; 182 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 106 | 90.6% |
| adapter / harness / other | 11 | 9.4% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 90.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:953:appendToNode`: 62.4% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:661:positionInBuffer`: 17.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:868:computeBufferMetadata`: 2.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 2.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:41:createLineStartsFast`: 1.7% of in-workload samples.

## mixed-edit-churn

1500 logical operations per replay.

### vscode

CPU: 554 in-workload samples; 157 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 354 | 63.9% |
| red-black tree | 167 | 30.1% |
| adapter / harness / other | 33 | 6.0% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 56.1% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 37.5% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 28.0% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:936:shrinkNode`: 27.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 24.7% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 24.2% of in-workload samples.

### singapore

CPU: 2029 in-workload samples; 138 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| reverse index | 794 | 39.1% |
| piece tree | 707 | 34.8% |
| buffer store / line index | 259 | 12.8% |
| adapter / harness / other | 242 | 11.9% |
| edit preparation / boundary policy | 27 | 1.3% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:208:applyBatchToPieceTable`: 73.5% of in-workload samples.
- `textbuffer/dist/edits.js:129:finishEdit`: 43.1% of in-workload samples.
- `textbuffer/dist/edits.js:160:replaceRange`: 42.6% of in-workload samples.
- `textbuffer/dist/tree.js:302:hideVisibleRange`: 42.2% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:99:applyReverseIndexChanges`: 25.0% of in-workload samples.
- `textbuffer/dist/reverseIndex.js:75:insertReverseIndexNode`: 24.9% of in-workload samples.

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

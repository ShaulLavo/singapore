import path from 'node:path'
import { readFileSync } from 'node:fs'
const bench = '/work/projects/Editor/packages/textbuffer/bench'
const { loadAdapter } = await import(path.join(bench, 'adapters.mjs'))
const { execute, validate } = await import(path.join(bench, 'worker.mjs'))
const [root, lane, count, seed, check] = process.argv.slice(2)
const fixture = JSON.parse(readFileSync(new URL(`fixtures/${seed}-${lane}.json`, import.meta.url), 'utf8'))
const factory = await loadAdapter('singapore', { singapore: root })
const out = []
for (let index = 0; index < Number(count); index += 1) { const r = execute(factory, fixture); if (check === 'check') validate(factory, fixture, r); if (check === 'digest' && r.checksum !== fixture.expectedDigest) throw new Error('digest'); out.push(r.elapsedMs.toFixed(2)) }
console.log(out.join(' '))

// node drive.mjs <warmups> <samples> <name=distRoot>... ; interleaved, medians over seeds
import { execFileSync } from 'node:child_process'
const [warmups, samples, ...builds] = process.argv.slice(2)
const lanes = (process.env.LANES ?? 'sequential-typing,random-insertions,random-replacements,eight-cursor-batches,mixed-edit-churn,anchor-resolution-after-churn').split(',')
const seeds = (process.env.SEEDS ?? '20260916,7,42').split(',')
const median = (values) => values.toSorted((a, b) => a - b)[values.length >> 1]
const rows = []
for (const lane of lanes) {
  const row = { lane }
  for (const build of builds) row[build.split('=')[0]] = []
  for (const seed of seeds) {
    const perBuild = Object.fromEntries(builds.map((build) => [build.split('=')[0], []]))
    for (let sample = 0; sample < Number(samples); sample += 1)
      for (const build of sample % 2 ? builds.toReversed() : builds) {
        const [name, root] = build.split('=')
        const out = execFileSync('node', ['--expose-gc', new URL('lane.mjs', import.meta.url).pathname, root, lane, warmups, seed], { encoding: 'utf8' })
        perBuild[name].push(Number(out))
      }
    for (const name of Object.keys(perBuild)) row[name].push(median(perBuild[name]))
  }
  for (const build of builds) { const name = build.split('=')[0]; row[name] = Number(median(row[name]).toFixed(3)) }
  rows.push(row)
  console.log(JSON.stringify(row))
}

# Textbuffer diagnostic attribution

Node v26.7.0; V8 14.6.202.34-node.28; Intel(R) Core(TM) i7-14700K.
Fixture profile standard, seed 20260916, retention always; upstream fdca8848ba80c9421cce1894bc32851e1730bc88.

**Diagnostic runs are not benchmark scores. CPU, sampled allocations, GC, and counters run in separate processes.**
Setup, warmup, correctness checks and forced collections are outside each diagnostic window.
CPU percentages below use only samples with runOperations on the stack. GC and profiler frames without that stack are excluded; GC has its own clean-build pass.
Heap bytes estimate JS-heap allocations (including collected objects), not exact or retained bytes; typed-array backing stores and native memory are excluded. Inclusive rows overlap; exclusive categories do not.

## random-insertions

1500 logical operations per replay.

### singapore

CPU: 376 in-workload samples; 59 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 230 | 61.2% |
| buffer store / line index | 83 | 22.1% |
| reverse index | 37 | 9.8% |
| edit preparation / boundary policy | 14 | 3.7% |
| adapter / harness / other | 12 | 3.2% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:171:insertIntoPieceTable`: 96.8% of in-workload samples.
- `textbuffer/dist/edits.js:143:insertText`: 84.0% of in-workload samples.
- `textbuffer/dist/tree.js:168:insertAtVisibleOffset`: 83.2% of in-workload samples.
- `textbuffer/dist/tree.js:206:insertAtLanding`: 34.0% of in-workload samples.
- `textbuffer/dist/tree.js:194:rejoinAfterInsert`: 23.1% of in-workload samples.
- `textbuffer/dist/join.js:61:join`: 21.5% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 375 | 0.25 |
| buffers.growTailLineIndex.indexInputCodeUnits | 2249 | 1.50 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| join.join.calls | 18438 | 12.29 |
| join.rotateLeft.calls | 322 | 0.21 |
| join.rotateRight.calls | 322 | 0.21 |
| node.cloneNode.calls | 15449 | 10.30 |
| node.createNode.calls | 2995 | 2.00 |
| node.own.calls | 18263 | 12.18 |
| reverseIndex.appendSlot.calls | 1500 | 1.00 |
| reverseIndex.copyBranch.calls | 163 | 0.11 |

### vscode

CPU: 253 in-workload samples; 46 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 157 | 62.1% |
| red-black tree | 91 | 36.0% |
| adapter / harness / other | 5 | 2.0% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:485:insert`: 97.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 29.2% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 26.9% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 22.5% of in-workload samples.
- `vscode/dist/rbTreeBase.js:355:recomputeTreeMetadata`: 18.6% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:982:nodeAt`: 16.6% of in-workload samples.

Structure after workload: {"pieces":2996,"invisible":0,"visible":2996,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 2250 | 1.50 |
| pieceTreeBase.createLineStartsFast.loopIterations | 2250 | 1.50 |
| rbTreeBase.leftRotate.calls | 1800 | 1.20 |
| rbTreeBase.rightRotate.calls | 1800 | 1.20 |
| rbTreeBase.TreeNode.constructor.calls | 2995 | 2.00 |

## random-replacements

1500 logical operations per replay.

### vscode

CPU: 293 in-workload samples; 53 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| VS Code buffer / line index | 204 | 69.6% |
| red-black tree | 76 | 25.9% |
| adapter / harness / other | 13 | 4.4% |

Inclusive hot stacks (not additive):

- `vscode/dist/pieceTreeBase.js:563:delete`: 52.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:485:insert`: 43.3% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:647:insertContentToNodeRight`: 30.7% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:1251:rbInsertRight`: 22.9% of in-workload samples.
- `vscode/dist/rbTreeBase.js:303:fixInsert`: 21.2% of in-workload samples.
- `vscode/dist/pieceTreeBase.js:736:createNewPieces`: 19.5% of in-workload samples.

Structure after workload: {"pieces":2917,"invisible":0,"visible":2917,"maxDepth":14}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| pieceTreeBase.createLineStartsFast.indexInputCodeUnits | 3380 | 2.25 |
| pieceTreeBase.createLineStartsFast.loopIterations | 3380 | 2.25 |
| rbTreeBase.leftRotate.calls | 1726 | 1.15 |
| rbTreeBase.rightRotate.calls | 1755 | 1.17 |
| rbTreeBase.TreeNode.constructor.calls | 2950 | 1.97 |

### singapore

CPU: 602 in-workload samples; 60 excluded. 

| Exclusive CPU category | Samples | Share |
| --- | ---: | ---: |
| piece tree | 313 | 52.0% |
| buffer store / line index | 113 | 18.8% |
| adapter / harness / other | 96 | 15.9% |
| reverse index | 51 | 8.5% |
| edit preparation / boundary policy | 29 | 4.8% |

Inclusive hot stacks (not additive):

- `textbuffer/dist/edits.js:206:applyBatchToPieceTable`: 94.7% of in-workload samples.
- `textbuffer/dist/edits.js:158:replaceRange`: 67.9% of in-workload samples.
- `textbuffer/dist/tree.js:296:hideVisibleRange`: 67.6% of in-workload samples.
- `textbuffer/dist/tree.js:258:hidePieceRange`: 37.9% of in-workload samples.
- `textbuffer/dist/join.js:61:join`: 22.3% of in-workload samples.
- `textbuffer/dist/edits.js:199:snappedEdits`: 15.3% of in-workload samples.

Structure after workload: {"pieces":4437,"invisible":1520,"visible":2917,"maxDepth":15,"chunks":2}.

| Work counter (first replay) | Count | Per logical operation |
| --- | ---: | ---: |
| buffers.countLineBreaks.loopIterations | 187 | 0.12 |
| buffers.growTailLineIndex.indexInputCodeUnits | 3376 | 2.25 |
| buffers.PieceBufferChunkView.fill.calls | 1499 | 1.00 |
| buffers.PieceBufferChunkView.open.calls | 1 | 0.00 |
| edits.snapEditRange.calls | 1453 | 0.97 |
| join.join.calls | 18969 | 12.65 |
| join.rotateLeft.calls | 797 | 0.53 |
| join.rotateRight.calls | 1126 | 0.75 |
| node.cloneNode.calls | 15859 | 10.57 |
| node.createNode.calls | 4436 | 2.96 |
| node.own.calls | 24017 | 16.01 |
| reads.splitsSurrogatePair.calls | 2906 | 1.94 |
| reverseIndex.appendSlot.calls | 1500 | 1.00 |
| reverseIndex.copyBranch.calls | 187 | 0.12 |
| reverseIndex.splitNode.calls | 24 | 0.02 |

## Limits

Function/loop counters are exact executed events in the instrumented copy, not time attribution. Recursion and nested loop counts are explicitly not unique-node counts.
Copied array slots count logical page/tail elements, not physical bytes allocated by V8. Native string searches are not instrumented per character.
Compare these signals with separate clean timing runs. A busy function is an optimization lead, not proof that disabling persistence or tombstones is valid.
Raw .cpuprofile and .heapprofile files can be loaded in Chromium DevTools. Per-replay GC events, all counters, cold/warm query counts and hashes are in JSON.

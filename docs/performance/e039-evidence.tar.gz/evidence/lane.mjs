// One fresh-process sample: node --expose-gc lane.mjs <distRoot> <lane> <warmups> <seed>
import path from 'node:path'
const bench = '/work/projects/Editor/packages/textbuffer/bench'
const { loadAdapter } = await import(path.join(bench, 'adapters.mjs'))
const { execute } = await import(path.join(bench, 'worker.mjs'))
import { readFileSync } from 'node:fs'
const [root, lane, warmups, seed] = process.argv.slice(2)
const fixture = JSON.parse(readFileSync(new URL(`fixtures/${seed}-${lane}.json`, import.meta.url), 'utf8'))
const factory = await loadAdapter('singapore', { singapore: root })
// The measured run shares the warmups' call site: a separate one reads 4x slower.
let elapsed = 0
for (let index = 0; index <= Number(warmups); index += 1) elapsed = execute(factory, fixture).elapsedMs
process.stdout.write(String(elapsed) + '\n')

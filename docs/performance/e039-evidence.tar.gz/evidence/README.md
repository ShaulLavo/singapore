# E039 evidence

- `drive.mjs`, `lane.mjs`: the throwaway driver. One fresh Node process per sample, builds interleaved,
  median per seed, then median over seeds 20260916, 7 and 42. `fixtures.mjs` writes the bench fixtures
  to files first. The measured run shares the warmups' call site: run from a second call site after
  8 warmups, typing read 1.64 ms where the bench reads 0.42.
- `ceiling-8w.jsonl`: E045 head against the build with the index disabled (`patches/no-index.diff`).
- `v2-vs-v3.jsonl`: plan option 1 as written, the original buffer indexed like any other
  (`patches/option1-*.diff`, applied to the emitted build), against the retained design.
- `v3-8w.jsonl`: the first build of the retained design, before its header objects shared one shape.
- `final-8w.jsonl`, `final-2w.jsonl`: E045 head against the final build, 9 samples.
- `official-final*.json`: `bun run bench` on the final build, three seeds.
- `anchors-base-8w.jsonl`: the anchor lanes on the E045 head, recorded when the density lane was added.
- `budgets-before.json`: the counter budgets of the E045 head.
- `profile/`: `bench:profile` cpu and counters for the two random lanes on the final build.
- `bugcheck.mjs <dist>`: the whole-insert deleted anchor, on any build.

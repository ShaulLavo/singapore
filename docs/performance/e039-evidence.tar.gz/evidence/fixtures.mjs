import { writeFileSync, mkdirSync } from 'node:fs'
const { makeFixtures } = await import('/work/projects/Editor/packages/textbuffer/bench/fixtures.mjs')
mkdirSync('fixtures', { recursive: true })
for (const seed of [20260916, 7, 42])
  for (const fixture of makeFixtures('standard', seed))
    if (fixture.mode !== 'load' && fixture.mode !== 'query') writeFileSync(`fixtures/${seed}-${fixture.name}.json`, JSON.stringify(fixture))

import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { Language, Parser, Query } from '../src';
import { marshalNode } from '../src/marshal';
import { C, SIZE_OF_INT } from '../src/constants';
import { TRANSFER_BUFFER } from '../src/parser';
import helper from './helper';

let JavaScript: Language;
const dispose: (() => void)[] = [];
beforeAll(async () => { ({ JavaScript } = await helper); });
afterEach(() => { for (const release of dispose.splice(0).reverse()) release(); });

function fixture(source: string) {
  const parser = new Parser();
  parser.setLanguage(JavaScript);
  dispose.push(() => { parser.delete(); });
  const tree = parser.parse(source)!;
  dispose.push(() => { tree.delete(); });
  const query = new Query(JavaScript, `
    ((identifier) @first (#eq? @first "alpha"))
    ((identifier) @rejected (#eq? @rejected "missing"))
    ((identifier) @last (#match? @last "^alpha$"))
  `);
  dispose.push(() => { query.delete(); });
  return { tree, query };
}

describe('query capture materialization', () => {
  it('keeps accepted capture arrays through later rejected matches', () => {
    const { tree, query } = fixture('let alpha = beta; alpha;');
    const matches = query.matches(tree.rootNode);
    expect(matches.map(match => match.captures.map(capture => [capture.name, capture.node.startIndex])))
      .toEqual([[['first', 4]], [['last', 4]], [['first', 18]], [['last', 18]]]);
    expect(new Set(matches.map(match => match.captures)).size).toBe(matches.length);
  });

  it('marshals native row and column without materializing a point', () => {
    const { tree } = fixture('\nlet alpha = beta;');
    const node = tree.rootNode.namedChild(0)!;
    expect(Object.hasOwn(node, 'startPosition')).toBe(false);
    expect(node['_startPosition']).toBeUndefined();
    expect(node.endIndex).toBe(18);
    expect(node['_startPosition']).toBeUndefined();
    marshalNode(node);
    expect(C.getValue(TRANSFER_BUFFER + 2 * SIZE_OF_INT, 'i32')).toBe(1);
    expect(C.getValue(TRANSFER_BUFFER + 3 * SIZE_OF_INT, 'i32')).toBe(0);
    const point = node.startPosition;
    expect(point).toEqual({ row: 1, column: 0 });
    expect(node.startPosition).toBe(point);
    point.column = 3;
    marshalNode(node);
    expect(C.getValue(TRANSFER_BUFFER + 3 * SIZE_OF_INT, 'i32')).toBe(3);
    node.startPosition = { row: 2, column: 7 };
    marshalNode(node);
    expect(C.getValue(TRANSFER_BUFFER + 2 * SIZE_OF_INT, 'i32')).toBe(2);
    expect(C.getValue(TRANSFER_BUFFER + 3 * SIZE_OF_INT, 'i32')).toBe(7);
  });
});

#!/usr/bin/env bash
set -euo pipefail
export PATH=$HOME/.local/share/mise/shims:$PATH
out=/work/reports/plan-339/qualification/error-free-walk-experiment
roots=(/work/worktrees/platform/plan-339-span-map /work/worktrees/platform/plan-339-error-free-walk)
[[ ! -e "$out" ]]
mkdir -p "$out"
cmp "${roots[0]}/bun.lock" "${roots[1]}/bun.lock"
cat > "$out/classification.json" <<'CLASSIFICATION'
{
  "kind": "prospective paired diagnostic experiment, not qualification",
  "date": "2026-10-09",
  "baseline": "shipping span-map consumer f24e3861a2977184aa811613264f2afeadcd7215",
  "candidate": "same source plus subtree error-flag guard on per-node missing checks",
  "coldOrder": ["baseline", "candidate"],
  "warmOrder": ["candidate", "baseline"],
  "repetitionsPerSideAndCondition": 1,
  "condition": "quiet",
  "qualification": false,
  "hostRecipe": "archival and host-specific; not a portable committed test"
}
CLASSIFICATION
for role in baseline candidate; do
  index=0; [[ "$role" != candidate ]] || index=1
  root=${roots[$index]}
  cp "$root/editor/packages/tree-sitter/src/treeSitter/treeSitter.worker.ts" "$out/$role-treeSitter.worker.ts"
  cp "$root/editor/bench/compare/full-document.mjs" "$out/$role-full-document.mjs"
  git -C "$root" status --porcelain > "$out/$role-source-status.txt"
  bash /work/tmp/wave-heavy/run.sh --class build "plan339 error-free walk $role build" -- env PATH="$PATH" bash -euo pipefail -c 'cd "$1/editor/bench/compare"; node build.mjs --full-document' _ "$root"
done
for startup in cold warm; do
  roles=(baseline candidate); extra=()
  [[ "$startup" != warm ]] || { roles=(candidate baseline); extra=(--warm); }
  for role in "${roles[@]}"; do
    index=0; [[ "$role" != candidate ]] || index=1
    bash /work/tmp/quiet-turn.sh "plan339 error-free walk diagnostic $startup $role" --class bench -- env PATH="$PATH" PLAYWRIGHT_BROWSERS_PATH=/work/cache/ms-playwright bash -euo pipefail -c 'exec 9>/work/tmp/wave-heavy/admission.lock; flock 9; cd "$1/editor/bench/compare"; shift; node run.mjs "$@"' _ "${roots[$index]}" --profile-open --open-only --full-document --sizes 10 --editors singapore --repetitions 1 --timeout 60000 --condition quiet --output "$out/$startup/$role" "${extra[@]}"
  done
  node "${roots[0]}/editor/bench/compare/summarize-open.mjs" "$out/$startup/candidate/experiment.json" --compare "$out/$startup/baseline/experiment.json" > "$out/$startup-comparison.json"
done
python3 - "$out" <<'PY'
import json,pathlib,sys
p=pathlib.Path(sys.argv[1])
frozen=json.load(open('/work/reports/plan-339/qualification/capture-consumer-published-smoke/experiment.json'))['samples'][0]['outputProof']
rows=[]
for startup in ['cold','warm']:
    for role in ['baseline','candidate']:
        d=json.load(open(p/startup/role/'experiment.json'))
        assert len(d['samples'])==1
        s=d['samples'][0]
        assert s['status']=='ok' and not s['errors']
        assert s['outputProof']==frozen
        req=next(r for r in s['openProfile']['requests'] if r.get('type')=='parse' and r.get('timings'))
        phases={t['name']:t['durationMs'] for t in req['timings']}
        worker=phases['treeSitter.parse']+phases['treeSitter.query']
        row={'startup':startup,'role':role,'frameMs':s['open'],'workerMs':worker,'mainWorkMs':s['openProfile']['mainWorkMs'],'diagnosticWorkMs':worker+s['openProfile']['mainWorkMs'],'structuralWalkMs':phases['treeSitter.structuralWalk'],'phasesMs':phases,'outputProof':s['outputProof']}
        rows.append(row)
        print(json.dumps({k:v for k,v in row.items() if k not in ['phasesMs','outputProof']}))
(p/'summary.json').write_text(json.dumps({'label':'Single-pair diagnostic experiment, not qualification','rows':rows},indent=2)+'\n')
PY

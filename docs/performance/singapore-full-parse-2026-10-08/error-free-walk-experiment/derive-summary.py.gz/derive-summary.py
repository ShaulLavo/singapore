import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
frozen = json.loads(pathlib.Path(sys.argv[2]).read_text())['samples'][0]['outputProof']
canonical = ['tokenCount', 'injectionCount', 'errorCount', 'tokenSha256', 'stylesSha256',
             'structuralSha256', 'firstToken', 'lastToken', 'missingLanguages', 'coverage',
             'matchLimitExceeded']
rows = []
for startup in ['cold', 'warm']:
    sides = {}
    for role in ['baseline', 'candidate']:
        experiment = json.loads((root / startup / role / 'experiment.json').read_text())
        assert len(experiment['samples']) == 1
        sample = experiment['samples'][0]
        assert sample['status'] == 'ok' and not sample['errors']
        for key in canonical:
            assert sample['outputProof'][key] == frozen[key], (startup, role, key)
        sides[role] = sample['outputProof']
        request = next(item for item in sample['openProfile']['requests']
                       if item.get('type') == 'parse' and item.get('timings'))
        phases = {item['name']: item['durationMs'] for item in request['timings']}
        worker = phases['treeSitter.parse'] + phases['treeSitter.query']
        main = sample['openProfile']['mainWorkMs']
        row = {'startup': startup, 'role': role,
               'frameMs': sample['open']['highlightedFrameMs'], 'workerMs': worker,
               'mainWorkMs': main, 'diagnosticWorkMs': worker + main,
               'structuralWalkMs': phases['treeSitter.structuralWalk'],
               'phasesMs': phases, 'outputProof': sample['outputProof']}
        rows.append(row)
        print(json.dumps({key: value for key, value in row.items()
                          if key not in ['phasesMs', 'outputProof']}))
    assert sides['baseline'] == sides['candidate'], startup
summary = {
    'label': 'Single-pair diagnostic experiment, not qualification',
    'rows': rows,
    'canonicalOutputEqual': True,
    'fullProofEqualWithinEachStartupCondition': True,
    'strictEnvironmentComparisons': ['cold-comparison.json', 'warm-comparison.json'],
    'analysisCorrection': 'The initial postprocessing assertion compared warm resource counters '
        'to a cold smoke. Both warm sides retain the accepted prime document: WASM capacity is '
        '350683136 versus 329187328 cold, and observed queries are 48 versus 42 cold. '
        'All output fields and both within-condition full proofs are equal. Raw observations '
        'and strict comparison guards are unchanged; no sample was rerun.'
}
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')

# Parameterized archival setup. Use an owned candidate checkout; this changes its worker and build transform.
import argparse
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--checkout', required=True, type=Path)
parser.add_argument('--baseline-checkout', required=True, type=Path)
parser.add_argument('--output-directory', required=True, type=Path)
args = parser.parse_args()
root = args.checkout.resolve()
baseline = args.baseline_checkout.resolve()
output = args.output_directory.resolve()
assert root != baseline, 'Candidate and baseline must be separate owned checkouts'
output.mkdir(parents=True, exist_ok=True)
original_path = output / 'fused-cursor-original-full-document.mjs'
assert not original_path.exists(), 'Preserve the previous transform backup'

worker = 'editor/packages/tree-sitter/src/treeSitter/treeSitter.worker.ts'
(root / worker).write_bytes((baseline / worker).read_bytes())
p = root / 'editor/bench/compare/full-document.mjs'
original = p.read_text()
original_path.write_text(original)
runtime = """  if (id.endsWith('/web-tree-sitter/web-tree-sitter.js')) {
    return replaceRequired(code, '  gotoNextSibling() {', `  gotoNext() {
    marshalTreeCursor(this);
    try {
      if (C._ts_tree_cursor_goto_first_child_wasm(this.tree[0]) === 1) return true;
      if (C._ts_tree_cursor_goto_next_sibling_wasm(this.tree[0]) === 1) return true;
      while (C._ts_tree_cursor_goto_parent_wasm(this.tree[0]) === 1) {
        if (C._ts_tree_cursor_goto_next_sibling_wasm(this.tree[0]) === 1) return true;
      }
      return false;
    } finally {
      unmarshalTreeCursor(this);
    }
  }
  gotoNextSibling() {`)
  }
"""
old = """  while (true) {
    collectCursorDiagnostics(cursor, visitors, bracketStack, hasErrors)

    if (cursor.gotoFirstChild()) continue
    if (cursor.gotoNextSibling()) continue

    while (true) {
      if (!cursor.gotoParent()) return
      if (cursor.gotoNextSibling()) break
    }
  }
"""
new = """  do {
    collectCursorDiagnostics(cursor, visitors, bracketStack, hasErrors)
  } while (cursor.gotoNext())
"""
assert original.count('export function fullDocumentTransform(code, id) {') == 1
s = original.replace('export function fullDocumentTransform(code, id) {',
                     'export function fullDocumentTransform(code, id) {\n' + runtime)
needle = "  if (id.endsWith('/tree-sitter/src/treeSitter/treeSitter.worker.ts')) {"
assert s.count(needle) == 1
s = s.replace(needle, needle + '\n    code = replaceRequired(code, ' + repr(old) + ', ' + repr(new) + ')\n')
p.write_text(s)

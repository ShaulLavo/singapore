#!/usr/bin/env bash
# Path-parameterized archival copy. Supply host scheduling wrappers with the original CLI contracts.
set -euo pipefail
: "${BASELINE_CHECKOUT:?Set the owned baseline checkout}"
: "${CANDIDATE_CHECKOUT:?Set the owned candidate checkout}"
: "${OUTPUT_DIRECTORY:?Set a fresh output directory}"
: "${BUILD_RUNNER:?Set the build scheduling wrapper}"
: "${QUIET_RUNNER:?Set the quiet measurement scheduling wrapper}"
: "${ADMISSION_LOCK:?Set the scheduling admission lock}"
: "${PLAYWRIGHT_BROWSERS_PATH:?Set the browser cache}"
: "${FROZEN_OUTPUT_PROOF:?Set the retained canonical experiment JSON}"
archive_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
export ADMISSION_LOCK
out=$OUTPUT_DIRECTORY
roots=("$BASELINE_CHECKOUT" "$CANDIDATE_CHECKOUT")
[[ ! -e "$out" ]]
mkdir -p "$out"
cmp "${roots[0]}/bun.lock" "${roots[1]}/bun.lock"
cat > "$out/classification.json" <<'CLASSIFICATION'
{
  "kind": "prospective paired diagnostic experiment, not qualification",
  "date": "2026-10-09",
  "baseline": "shipping error-free-walk candidate e68663768bee4bd3b7d7de3acbb9bc7549154406",
  "candidate": "same source plus experiment-only full-walk gotoNext using one marshal/unmarshal pair and unchanged native movement functions",
  "coldOrder": ["baseline", "candidate"],
  "warmOrder": ["candidate", "baseline"],
  "repetitionsPerSideAndCondition": 1,
  "condition": "quiet",
  "qualification": false,
  "hostRecipe": "archival and host-specific; not a portable committed test"
}
CLASSIFICATION
for role in baseline candidate; do
  index=0; [[ "$role" != candidate ]] || index=1
  root=${roots[$index]}
  cp "$root/editor/packages/tree-sitter/src/treeSitter/treeSitter.worker.ts" "$out/$role-treeSitter.worker.ts"
  cp "$root/editor/bench/compare/full-document.mjs" "$out/$role-full-document.mjs"
  git -C "$root" status --porcelain > "$out/$role-source-status.txt"
  bash "$BUILD_RUNNER" --class build "plan339 fused cursor $role build" -- env PATH="$PATH" bash -euo pipefail -c 'cd "$1/editor/bench/compare"; node build.mjs --full-document' _ "$root"
done
for startup in cold warm; do
  roles=(baseline candidate); extra=()
  [[ "$startup" != warm ]] || { roles=(candidate baseline); extra=(--warm); }
  for role in "${roles[@]}"; do
    index=0; [[ "$role" != candidate ]] || index=1
    bash "$QUIET_RUNNER" "plan339 fused cursor diagnostic $startup $role" --class bench -- env PATH="$PATH" PLAYWRIGHT_BROWSERS_PATH="$PLAYWRIGHT_BROWSERS_PATH" bash -euo pipefail -c 'exec 9>"$ADMISSION_LOCK"; flock 9; cd "$1/editor/bench/compare"; shift; node run.mjs "$@"' _ "${roots[$index]}" --profile-open --open-only --full-document --sizes 10 --editors singapore --repetitions 1 --timeout 60000 --condition quiet --output "$out/$startup/$role" "${extra[@]}"
  done
  node "${roots[0]}/editor/bench/compare/summarize-open.mjs" "$out/$startup/candidate/experiment.json" --compare "$out/$startup/baseline/experiment.json" > "$out/$startup-comparison.json"
done
python3 "$archive_dir/provenance/derive-error-free-walk.py" "$out" "$FROZEN_OUTPUT_PROOF"

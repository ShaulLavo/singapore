#!/usr/bin/env bash
set -euo pipefail
export PATH=$HOME/.local/share/mise/shims:$PATH
out=/work/reports/plan-339/qualification/normalization-span-map-experiment
[[ ! -e "$out" ]]
mkdir -p "$out"
cmp /work/worktrees/platform/plan-339-predicate-profile/bun.lock /work/worktrees/platform/plan-339-capture-profile/bun.lock
roots=(/work/worktrees/platform/plan-339-predicate-profile /work/worktrees/platform/plan-339-capture-profile)
restore() {
 for role in baseline candidate; do
  index=0; [[ "$role" != candidate ]] || index=1
  [[ ! -f "$out/$role-full-document.mjs" ]] || cp "$out/$role-full-document.mjs" "${roots[$index]}/editor/bench/compare/full-document.mjs"
 done
}
trap restore EXIT
for role in baseline candidate; do
 index=0; [[ "$role" != candidate ]] || index=1
 root=${roots[$index]}
 cp "$root/editor/bench/compare/full-document.mjs" "$out/$role-full-document.mjs"
 python3 - "$root/editor/bench/compare/full-document.mjs" "$role" <<'PY'
import pathlib,sys
p=pathlib.Path(sys.argv[1]); s=p.read_text(); needle="  if (id.endsWith('/tree-sitter/src/treeSitter/treeSitter.worker.ts')) {"; assert s.count(needle)==1
s=s.replace(needle,needle+'''
    code = replaceRequired(code,
      'const start = nowMs()\\n  try {\\n    return run()\\n  } finally {',
      `if (name === 'overlapResolution') performance.mark('compare.overlap.start')
      const start = nowMs()
      try { return run() } finally {
      if (name === 'overlapResolution') performance.mark('compare.overlap.end')`)
''')
if True:
 s="import { readFileSync } from 'node:fs'\n"+s
 a='export function fullDocumentTransform(code, id) {'; assert s.count(a)==1
 s=s.replace(a,a+"\n  if (id.endsWith('/web-tree-sitter/web-tree-sitter.js')) return readFileSync('/work/worktrees/tree-sitter-x/plan-339-capture-materialization/lib/binding_web/web-tree-sitter.js', 'utf8')")
if True:
 old = """  const matches = measurePhase(context, 'highlightQueryAndPredicates', () =>
    query.matches(rootNode, queryOptions(context, range)),
  )
  assertNotCancelled(context)

  for (const match of matches) {
    incrementCount(context, 'rawCaptures', match.captures.length)
    collectMatchCaptures(match.captures, captures, seen, runtime.descriptor.id, range)
  }
"""
 new = """  const queryCaptures = measurePhase(context, 'highlightQueryAndPredicates', () =>
    query.captureRanges(rootNode, queryOptions(context, range)),
  )
  assertNotCancelled(context)
  incrementCount(context, 'rawCaptures', queryCaptures.length)
  for (const capture of queryCaptures) {
    collectCapture(capture, captures, seen, runtime.descriptor.id, range)
  }
"""
 marker="  if (id.endsWith('/tree-sitter/src/treeSitter/treeSitter.worker.ts')) {"
 injection="\n    code = replaceRequired(code, "+repr(old)+", "+repr(new)+")\n    code = replaceRequired(code, '  const node = capture.node\\n  if (!node) return\\n\\n  const startIndex = node.startIndex', \"  const node = 'node' in capture ? capture.node : capture\\n  if (!node) return\\n\\n  const startIndex = node.startIndex\")\n"
 assert s.count(marker)==1
 s=s.replace(marker, marker+injection)
s = s.replace("for (const method of ['matches', 'captures'] as const)", "for (const method of ['matches', 'captures', 'captureRanges'] as const)")
s = s.replace('const original = Query.prototype[method]', "const original = Query.prototype[method]\n      if (typeof original !== 'function') continue")
if sys.argv[2]=='candidate':
 old_loop = """  for (const capture of queryCaptures) {
    collectCapture(capture, captures, seen, runtime.descriptor.id, range)
  }
"""
 new_loop = """  queryCaptures.sort((a, b) => a.startIndex - b.startIndex || a.endIndex - b.endIndex)
  const lastSpanByName = new Map<string, number>()
  let span = 0
  let previousStart = -1
  let previousEnd = -1
  for (const capture of queryCaptures) {
    const { startIndex, endIndex } = capture
    if (startIndex >= endIndex) continue
    if (startIndex !== previousStart || endIndex !== previousEnd) {
      span++
      previousStart = startIndex
      previousEnd = endIndex
    }
    const captureName = capture.name ?? ''
    if (lastSpanByName.get(captureName) === span) continue
    lastSpanByName.set(captureName, span)
    captures.push({ startIndex, endIndex, captureName, languageId: runtime.descriptor.id })
  }
"""
 anchor = "    code = replaceRequired(code,\n      'const start = nowMs()"
 assert s.count(anchor)==1
 injection = "    code = replaceRequired(code, " + repr(old_loop) + ", " + repr(new_loop) + ")\n"
 s = s.replace(anchor, injection + anchor)
p.write_text(s)
PY
 bash /work/tmp/wave-heavy/run.sh --class build "plan339 compact ranges experiment $role build" -- env PATH="$PATH" bash -euo pipefail -c 'cd "$1"; bun run --cwd editor/bench/compare build:full' _ "$root"
done
for startup in cold warm; do
 roles=(baseline candidate); extra=(); [[ "$startup" != warm ]] || { roles=(candidate baseline); extra=(--warm); }
 for role in "${roles[@]}"; do
  index=0; [[ "$role" != candidate ]] || index=1
  bash /work/tmp/quiet-turn.sh "plan339 compact ranges exploratory $startup $role" --class bench -- env PATH="$PATH" PLAYWRIGHT_BROWSERS_PATH=/work/cache/ms-playwright bash -euo pipefail -c 'exec 9>/work/tmp/wave-heavy/admission.lock; flock 9; cd "$1/editor/bench/compare"; shift; node run.mjs "$@"' _ "${roots[$index]}" --profile-open --open-only --full-document --sizes 10 --editors singapore --repetitions 1 --timeout 60000 --condition quiet --output "$out/$startup/$role" "${extra[@]}"
 done
done
restore
trap - EXIT
